import os
import re
import sys
import json
import requests
from fpdf import FPDF
from fpdf.fonts import FontFace
import matplotlib.pyplot as plt
import numpy as np
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def clean_text(text):
    """Sanitizes text for FPDF latin-1 encoding."""
    if not isinstance(text, str): return str(text)
    replacements = {
        '\u2013': '-', # en dash
        '\u2014': '-', # em dash
        '\u2018': "'", # left single quote
        '\u2019': "'", # right single quote
        '\u201c': '"', # left double quote
        '\u201d': '"', # right double quote
        '\u2022': '*', # bullet point
        '\u2026': '...', # ellipsis
        '\u2122': '(TM)', # trademark
        '\u00ae': '(R)', # registered
        '\u00a9': '(C)', # copyright
    }
    for char, rep in replacements.items():
        text = text.replace(char, rep)
    # Final fallback for other non-latin1 characters
    return text.encode('latin-1', 'replace').decode('latin-1')

def format_content_for_txt(text, indent="      ", width=80):
    """Cleans up scraped content for TXT files: removes extra newlines and wraps text."""
    if not text: return "(no content)"
    # Remove excessive newlines
    text = re.sub(r'\n\s*\n', '\n\n', text)
    lines = []
    for paragraph in text.split('\n\n'):
        paragraph = re.sub(r'\s+', ' ', paragraph).strip()
        if not paragraph: continue
        
        # Simple word wrap
        words = paragraph.split(' ')
        current_line = []
        current_len = 0
        for word in words:
            if current_len + len(word) + 1 > width:
                lines.append(indent + " ".join(current_line))
                current_line = [word]
                current_len = len(word)
            else:
                current_line.append(word)
                current_len += len(word) + 1
        if current_line:
            lines.append(indent + " ".join(current_line))
        lines.append("") # paragraph break
    
    return "\n".join(lines).strip()

# =========================
# PDF CLASS
# =========================
class ReportPDF(FPDF):

    def __init__(self, partner_name="BASE ENTITY", *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.partner_name = partner_name.upper()

    def header(self):
        if self.page_no() > 1:
            self.set_font("Helvetica", "B", 8)
            self.set_text_color(120,120,120)
            self.cell(0, 5, f"{self.partner_name} | STRATEGIC COMPETITIVE INTELLIGENCE", 0, 1, "R")

    def section_title(self, title):
        title = clean_text(title)
        self.ln(5)
        self.set_fill_color(13, 71, 161)
        self.set_text_color(255,255,255)
        self.set_font("Helvetica","B",14)
        self.cell(0,10,title,0,1,"L",True)
        self.ln(5)

    def body_text(self, text):
        text = clean_text(text)
        self.set_text_color(33,37,41)
        self.set_font("Helvetica","",11)
        self.multi_cell(0, 6, text, align='J')
        self.ln(5)


# =========================
# COVER PAGE
# =========================
def add_cover(pdf, partner_name):
    pdf.add_page()

    pdf.set_fill_color(13,71,161)
    pdf.rect(0,0,210,160,"F")

    pdf.set_text_color(255,255,255)
    pdf.set_font("Helvetica","B",32)
    pdf.set_y(60)
    pdf.cell(0,15,"STRATEGIC MARKET",0,1,"C")
    pdf.cell(0,15,"INTELLIGENCE",0,1,"C")

    pdf.set_font("Helvetica","",14)
    pdf.cell(0,10,f"{partner_name} vs Analysis",0,1,"C")

    pdf.set_y(200)
    pdf.set_text_color(0,0,0)
    pdf.set_font("Helvetica","B",24)
    pdf.cell(0,10,partner_name.upper(),0,1,"C")


# =========================
# CHARTS
# =========================

def _apply_dark_base(fig, ax):
    """Apply shared dark intelligence-dashboard styling to any axes."""
    BG       = '#0D1117'
    PANEL    = '#161B22'
    GRID     = '#21262D'
    TEXT     = '#E6EDF3'
    SUBTEXT  = '#8B949E'

    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    ax.tick_params(colors=SUBTEXT, labelsize=9)
    ax.xaxis.label.set_color(SUBTEXT)
    ax.yaxis.label.set_color(SUBTEXT)

    for spine in ax.spines.values():
        spine.set_edgecolor(GRID)

    ax.grid(axis='x', color=GRID, linewidth=0.6, linestyle='--', alpha=0.7)
    ax.set_axisbelow(True)

    return BG, PANEL, GRID, TEXT, SUBTEXT


def chart_performance(partners, baseline_name):
    # ── FILTERING (Top 10 + Baseline) ─────────────────────────────────────────
    def get_total_score(p):
        s = p.get("scores", {}).values()
        total = 0
        for v in s:
            try: total += float(v)
            except: pass
        return total

    # Sort all by total score
    sorted_p = sorted(partners, key=get_total_score, reverse=True)
    
    # Get top 10 and ensure baseline is included
    top_10 = sorted_p[:10]
    baseline = next((p for p in partners if p["name"] == baseline_name), None)
    
    display_partners = top_10
    if baseline and baseline not in top_10:
        display_partners.append(baseline)
    
    # Re-sort display partners so the chart stays ordered
    display_partners = sorted(display_partners, key=get_total_score, reverse=True)
    
    # Use filtered list for chart
    names = [p["name"] for p in display_partners]
    tech, success, authority = [], [], []
    for p in display_partners:
        s = p.get("scores", {})
        try: tech.append(float(s.get("technical_depth", 0)))
        except: tech.append(0.0)
        try: success.append(float(s.get("customer_success", 0)))
        except: success.append(0.0)
        try: authority.append(float(s.get("market_authority", 0)))
        except: authority.append(0.0)

    # ── PALETTE ───────────────────────────────────────────────────────────────
    C_TECH    = '#58A6FF'   # cool blue
    C_SUCCESS = '#F0B429'   # amber
    C_AUTH    = '#3FB950'   # green
    C_BASE    = '#FF7B54'   # baseline highlight
    BG        = '#0D1117'
    PANEL     = '#161B22'
    GRID      = '#21262D'
    TEXT      = '#E6EDF3'
    SUBTEXT   = '#8B949E'

    height = max(0.55, min(0.85, 10 / max(len(names), 1)))
    fig, ax = plt.subplots(figsize=(12, max(6, len(names) * 0.55 + 2)))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    y_pos = range(len(names))
    bars_t = ax.barh(y_pos, tech,      height=height, label="Technical Depth",  color=C_TECH,    alpha=0.92)
    bars_s = ax.barh(y_pos, success,   height=height, left=tech,
                     label="Customer Success", color=C_SUCCESS, alpha=0.92)
    bars_a = ax.barh(y_pos, authority, height=height,
                     left=[t + s for t, s in zip(tech, success)],
                     label="Market Authority", color=C_AUTH, alpha=0.92)

    # Rounded end caps (thin white overlay on rightmost bar)
    totals = [t + s + a for t, s, a in zip(tech, success, authority)]
    for i, total in enumerate(totals):
        ax.barh(i, 2, height=height * 0.6, left=total - 1, color='white', alpha=0.15)

    # Value labels at end of each stacked bar
    for i, total in enumerate(totals):
        ax.text(total + 1.5, i, f'{int(total)}',
                va='center', ha='left', fontsize=8.5,
                color=TEXT, fontweight='bold')

    # Y-axis labels — highlight baseline
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(names, fontsize=9)
    for tick, name in zip(ax.get_yticklabels(), names):
        if name == baseline_name:
            tick.set_color(C_BASE)
            tick.set_fontweight('bold')
            tick.set_fontsize(10.5)
            # Subtle highlight band behind the baseline row
            row_idx = names.index(name)
            ax.axhspan(row_idx - height / 2, row_idx + height / 2,
                       color=C_BASE, alpha=0.07, zorder=0)
        else:
            tick.set_color(SUBTEXT)

    # Axes styling
    ax.tick_params(axis='x', colors=SUBTEXT, labelsize=8.5)
    ax.set_xlabel("Cumulative Strategic Score (0–300)", color=SUBTEXT, fontsize=9.5, labelpad=8)
    for spine in ax.spines.values():
        spine.set_edgecolor(GRID)
    ax.grid(axis='x', color=GRID, linewidth=0.5, linestyle='--', alpha=0.6)
    ax.set_axisbelow(True)
    ax.invert_yaxis()

    # Legend — dark card style
    legend = ax.legend(loc='lower right', fontsize=8.5, framealpha=0.0,
                       labelcolor=TEXT, borderpad=0.8)
    for patch in legend.get_patches():
        patch.set_alpha(0.9)

    # Title block
    fig.text(0.02, 0.97,
             f"MARKET PERFORMANCE INDEX",
             color=TEXT, fontsize=14, fontweight='bold',
             va='top', ha='left')
    fig.text(0.02, 0.93,
             f"{baseline_name.upper()} COMPETITIVE BENCHMARKING",
             color=SUBTEXT, fontsize=9, va='top', ha='left')

    # Thin top accent line
    fig.add_artist(plt.Line2D([0.02, 0.98], [0.99, 0.99],
                              transform=fig.transFigure,
                              color=C_TECH, linewidth=1.5, alpha=0.8))

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.savefig("performance.png", dpi=180, facecolor=BG)
    plt.close()


def chart_distribution(partners, baseline_name, baseline_score):
    # ── DATA (unchanged) ──────────────────────────────────────────────────────
    all_scores = []
    for p in partners:
        s = p.get("scores", {}).values()
        total = 0
        for v in s:
            try: total += float(v)
            except: pass
        all_scores.append(total)

    # ── PALETTE ───────────────────────────────────────────────────────────────
    BG      = '#0D1117'
    PANEL   = '#161B22'
    GRID    = '#21262D'
    TEXT    = '#E6EDF3'
    SUBTEXT = '#8B949E'
    C_BAR   = '#1F6FEB'
    C_BASE  = '#FF7B54'

    fig, ax = plt.subplots(figsize=(11, 6))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    # Histogram with gradient-like stacking
    n, bins, patches = ax.hist(all_scores, bins=12,
                                color=C_BAR, alpha=0.75,
                                edgecolor=BG, linewidth=0.8,
                                label="Partner Density")

    # Colour bars by proximity to baseline (warmer = closer)
    for patch, left in zip(patches, bins[:-1]):
        dist = abs((left + (bins[1] - bins[0]) / 2) - baseline_score)
        alpha = max(0.35, 1 - dist / (max(bins) - min(bins) + 1))
        patch.set_alpha(alpha)

    # Baseline vertical line
    ax.axvline(baseline_score, color=C_BASE, linestyle='--',
               linewidth=2.2, label=f"{baseline_name} Position", zorder=5)

    # Filled area under baseline
    ax.axvspan(baseline_score - 5, baseline_score + 5,
               color=C_BASE, alpha=0.08, zorder=1)

    # Annotation callout
    ymax = max(n)
    ax.annotate(
        f" {baseline_name.upper()}\n SCORE: {int(baseline_score)}",
        xy=(baseline_score, ymax * 0.68),
        xytext=(baseline_score + max(bins) * 0.07, ymax * 0.82),
        arrowprops=dict(arrowstyle='->', color=C_BASE,
                        lw=1.8, connectionstyle='arc3,rad=0.2'),
        color=C_BASE, fontweight='bold', fontsize=9,
        bbox=dict(boxstyle='round,pad=0.4', fc=PANEL, ec=C_BASE, lw=1.2)
    )

    # Axes styling
    ax.tick_params(colors=SUBTEXT, labelsize=8.5)
    ax.set_xlabel("Strategic Score (0–300)", color=SUBTEXT, fontsize=9.5, labelpad=8)
    ax.set_ylabel("Number of Partners",      color=SUBTEXT, fontsize=9.5, labelpad=8)
    for spine in ax.spines.values():
        spine.set_edgecolor(GRID)
    ax.grid(color=GRID, linewidth=0.5, linestyle='--', alpha=0.5)
    ax.set_axisbelow(True)

    legend = ax.legend(fontsize=8.5, framealpha=0, labelcolor=TEXT)

    # Title block
    fig.text(0.02, 0.97, "COHORT DISTRIBUTION",
             color=TEXT, fontsize=13, fontweight='bold', va='top')
    fig.text(0.02, 0.93, "MARKET AUTHORITY INDEX — PARTNER DENSITY CURVE",
             color=SUBTEXT, fontsize=8.5, va='top')
    fig.add_artist(plt.Line2D([0.02, 0.98], [0.99, 0.99],
                              transform=fig.transFigure,
                              color=C_BAR, linewidth=1.5, alpha=0.8))

    plt.tight_layout(rect=[0, 0, 1, 0.91])
    plt.savefig("distribution.png", dpi=180, facecolor=BG)
    plt.close()


def radar_chart(scores):
    # ── DATA (unchanged) ──────────────────────────────────────────────────────
    labels = [l.replace('_', ' ').title() for l in scores.keys()]
    values = []
    for v in scores.values():
        try: values.append(float(v))
        except: values.append(0.0)
    
    values += values[:1]
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    angles += angles[:1]

    # ── PALETTE ───────────────────────────────────────────────────────────────
    BG      = '#0D1117'
    PANEL   = '#0D1117'
    GRID    = '#21262D'
    TEXT    = '#E6EDF3'
    SUBTEXT = '#8B949E'
    C_LINE  = '#58A6FF'
    C_FILL  = '#1F6FEB'
    C_MARK  = '#FF7B54'

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw=dict(polar=True))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    # Concentric reference rings
    max_val = max(values[:-1]) if values[:-1] else 100
    for r_frac in [0.25, 0.5, 0.75, 1.0]:
        ring_vals = [max_val * r_frac] * (len(angles))
        ax.plot(angles, ring_vals, color=GRID, linewidth=0.7, linestyle='--', zorder=1)

    # Spoke gridlines
    for angle in angles[:-1]:
        ax.plot([angle, angle], [0, max_val], color=GRID, linewidth=0.7, zorder=1)

    # Filled area with gradient effect (two overlapping fills)
    ax.fill(angles, values, color=C_FILL, alpha=0.18, zorder=2)
    ax.fill(angles, [v * 0.6 for v in values], color=C_FILL, alpha=0.12, zorder=2)

    # Main polygon line
    ax.plot(angles, values, color=C_LINE, linewidth=2.2, zorder=3)

    # Data point markers
    ax.scatter(angles[:-1], values[:-1],
               color=C_MARK, s=55, zorder=4, edgecolors=BG, linewidths=1.5)

    # Value labels at each vertex
    for angle, value in zip(angles[:-1], values[:-1]):
        ax.text(angle, value + max_val * 0.08, f'{int(value)}',
                ha='center', va='center',
                color=TEXT, fontsize=8.5, fontweight='bold', zorder=5)

    # Axis labels
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, fontsize=9, fontweight='bold', color=TEXT)
    ax.set_yticklabels([])
    
    # Ensure we don't crash on zero max_val
    plot_max = max_val * 1.25 if max_val > 0 else 100
    ax.set_ylim(0, plot_max)
    ax.spines['polar'].set_edgecolor(GRID)
    ax.tick_params(pad=12)

    # Title
    fig.text(0.5, 0.97, "STRATEGIC PERFORMANCE RADAR",
             color=TEXT, fontsize=11, fontweight='bold',
             ha='center', va='top')
    fig.add_artist(plt.Line2D([0.15, 0.85], [0.985, 0.985],
                              transform=fig.transFigure,
                              color=C_LINE, linewidth=1.2, alpha=0.7))

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    plt.savefig("radar.png", dpi=180, bbox_inches='tight', facecolor=BG)
    plt.close()


def gap_chart(gap):
    # ── DATA (unchanged) ──────────────────────────────────────────────────────
    labels = [str(l) for l in gap.keys()]
    values = []
    for v in gap.values():
        try: values.append(float(v))
        except: values.append(0.0)

    # ── PALETTE ───────────────────────────────────────────────────────────────
    BG       = '#0D1117'
    PANEL    = '#161B22'
    GRID     = '#21262D'
    TEXT     = '#E6EDF3'
    SUBTEXT  = '#8B949E'
    C_POS    = '#3FB950'   # green  — ahead of market
    C_NEG    = '#F85149'   # red    — behind market
    C_ZERO   = '#8B949E'   # mid axis line

    fig, ax = plt.subplots(figsize=(11, max(5, len(labels) * 0.72 + 2)))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    colors = [C_POS if v >= 0 else C_NEG for v in values]
    bars   = ax.barh(labels, values, color=colors, alpha=0.88,
                     height=0.58, edgecolor=BG, linewidth=0.5)

    # Zero reference line
    ax.axvline(0, color=C_ZERO, linewidth=1.2, zorder=5)

    # Subtle background bands for readability
    for i in range(len(labels)):
        if i % 2 == 0:
            ax.axhspan(i - 0.45, i + 0.45, color='white', alpha=0.02, zorder=0)

    # Data labels — smart positioning
    for bar, val in zip(bars, values):
        w = bar.get_width()
        cy = bar.get_y() + bar.get_height() / 2
        if w < 0:
            ax.text(w - 1.2, cy, f'{int(w)}%',
                    va='center', ha='right', fontsize=9,
                    fontweight='bold', color=C_NEG)
        else:
            ax.text(w + 1.2, cy, f'+{int(w)}%',
                    va='center', ha='left', fontsize=9,
                    fontweight='bold', color=C_POS)

    # Axes styling
    ax.tick_params(axis='y', colors=TEXT, labelsize=9, pad=6)
    ax.tick_params(axis='x', colors=SUBTEXT, labelsize=8.5)
    ax.set_xlabel("Percentage Variance (%)", color=SUBTEXT, fontsize=9.5, labelpad=8)
    for spine in ax.spines.values():
        spine.set_edgecolor(GRID)
    ax.grid(axis='x', color=GRID, linewidth=0.5, linestyle='--', alpha=0.55)
    ax.set_axisbelow(True)

    # Legend chips
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=C_POS, label='Above Market Leaders', alpha=0.88),
        Patch(facecolor=C_NEG, label='Below Market Leaders',  alpha=0.88),
    ]
    ax.legend(handles=legend_elements, fontsize=8.5,
              framealpha=0, labelcolor=TEXT, loc='lower right')

    # Title block
    fig.text(0.02, 0.97, "COMPETITIVE GAP ANALYSIS",
             color=TEXT, fontsize=13, fontweight='bold', va='top')
    fig.text(0.02, 0.93, "DELTA VS MARKET LEADERS — PERCENTAGE VARIANCE",
             color=SUBTEXT, fontsize=8.5, va='top')
    fig.add_artist(plt.Line2D([0.02, 0.98], [0.99, 0.99],
                              transform=fig.transFigure,
                              color=C_NEG, linewidth=1.5, alpha=0.8))

    plt.tight_layout(rect=[0, 0, 1, 0.91])
    plt.subplots_adjust(left=0.42)
    plt.savefig("gap.png", dpi=180, facecolor=BG)
    plt.close()


def authority_chart(data):
    # ── DATA (unchanged) ──────────────────────────────────────────────────────
    labels = [f"{l.replace('_', ' ').title()} ({int(float(v)) if str(v).replace('.','',1).isdigit() else 0})" for l, v in data.items()]
    values = []
    for v in data.values():
        try: values.append(float(v))
        except: values.append(0.0)

    # ── PALETTE ───────────────────────────────────────────────────────────────
    BG      = '#0D1117'
    TEXT    = '#E6EDF3'
    SUBTEXT = '#8B949E'
    COLORS  = ['#58A6FF', '#F0B429', '#3FB950', '#F85149', '#BC8CFF']

    fig, ax = plt.subplots(figsize=(7, 7))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)

    wedges, texts, autotexts = ax.pie(
        values,
        labels=None,          # we'll draw a custom legend instead
        autopct='%1.1f%%',
        colors=COLORS,
        startangle=140,
        pctdistance=0.78,
        wedgeprops=dict(linewidth=2.5, edgecolor=BG),
    )

    # Percentage text styling
    plt.setp(autotexts, size=9.5, weight='bold', color='white')

    # Donut hole with inner label
    centre = plt.Circle((0, 0), 0.58, fc=BG)
    fig.gca().add_artist(centre)
    ax.text(0, 0.08, 'CAPABILITY', ha='center', va='center',
            color=SUBTEXT, fontsize=8, fontweight='bold')
    ax.text(0, -0.08, 'BALANCE', ha='center', va='center',
            color=SUBTEXT, fontsize=8, fontweight='bold')

    # Custom legend as colour chips
    from matplotlib.patches import Patch
    legend_patches = [
        Patch(facecolor=COLORS[i % len(COLORS)], label=labels[i], linewidth=0)
        for i in range(len(labels))
    ]
    leg = ax.legend(
        handles=legend_patches,
        loc='lower center',
        bbox_to_anchor=(0.5, -0.18),
        ncol=2,
        fontsize=8.2,
        framealpha=0,
        labelcolor=TEXT,
        handlelength=1.2,
        handleheight=1.0,
        borderpad=0.5,
    )

    plt.axis('equal')

    # Title block
    fig.text(0.5, 0.97, "STRATEGIC CAPABILITY BALANCE",
             color=TEXT, fontsize=11, fontweight='bold',
             ha='center', va='top')
    fig.add_artist(plt.Line2D([0.15, 0.85], [0.985, 0.985],
                              transform=fig.transFigure,
                              color=COLORS[0], linewidth=1.2, alpha=0.7))

    plt.tight_layout(rect=[0, 0.1, 1, 0.94])
    plt.savefig("authority.png", dpi=180, bbox_inches='tight', facecolor=BG)
    plt.close()


def chart_solutions(benchmarking_data, baseline_name):
    """Visualizes product-specific efficiency vs challenges."""
    if not benchmarking_data: return
    
    # Prep data — support both old and new key names
    data = benchmarking_data # Remove the [:12] limit to show all products
    products = [d.get('solution_identified', d.get('product_name', 'Solution')) for d in data]
    partners = [d.get('partner_name', 'Partner') for d in data]
    industries = [d.get('target_vertical', d.get('target_industry', 'Multi')) for d in data]
    
    efficiency = []
    for d in data:
        try: efficiency.append(float(d.get('efficiency_score', 0)))
        except: efficiency.append(0.0)
        
    challenges = []
    for d in data:
        try: challenges.append(float(d.get('complexity_score', d.get('challenge_score', 0))))
        except: challenges.append(0.0)

    # ── PALETTE ───────────────────────────────────────────────────────────────
    BG      = '#0D1117'
    PANEL   = '#161B22'
    GRID    = '#21262D'
    TEXT    = '#E6EDF3'
    SUBTEXT = '#8B949E'
    C_EFF   = '#3FB950'
    C_CHA   = '#F85149'
    C_BASE  = '#FF7B54'

    fig, ax = plt.subplots(figsize=(12, max(6, len(data) * 0.75 + 2)))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    y = np.arange(len(data))
    height = 0.35

    ax.barh(y - height/2, efficiency, height, label='Solution Efficiency', color=C_EFF, alpha=0.88)
    ax.barh(y + height/2, challenges, height, label='Technical Challenges', color=C_CHA, alpha=0.88)

    # Labels with Industry context
    y_labels = [f"{prod}\n({part}) | {ind}" for prod, part, ind in zip(products, partners, industries)]
    ax.set_yticks(y)
    ax.set_yticklabels(y_labels, fontsize=8.5, color=SUBTEXT)
    
    # Highlight baseline
    for i, label in enumerate(ax.get_yticklabels()):
        if baseline_name.lower() in partners[i].lower() or baseline_name.lower() in products[i].lower():
            label.set_color(C_BASE)
            label.set_fontweight('bold')
            label.set_fontsize(9.5)

    ax.tick_params(colors=SUBTEXT, labelsize=8.5)
    ax.set_xlabel("Maturity & Complexity Score (0–100)", color=SUBTEXT, fontsize=9.5)
    for spine in ax.spines.values(): spine.set_edgecolor(GRID)
    ax.grid(axis='x', color=GRID, linestyle='--', alpha=0.45)
    ax.invert_yaxis()
    
    ax.legend(loc='upper right', fontsize=8.5, framealpha=0, labelcolor=TEXT)

    fig.text(0.02, 0.97, "PRODUCT & SOLUTION BENCHMARKING", color=TEXT, fontsize=14, fontweight='bold', va='top')
    fig.text(0.02, 0.93, "COMPARATIVE ANALYSIS OF EFFICIENCY VS IMPLEMENTATION CHALLENGES", color=SUBTEXT, fontsize=9, va='top')
    
    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.savefig("solutions.png", dpi=180, facecolor=BG)
    plt.close()


# =========================
# MAIN REPORT FUNCTION
# =========================

def generate_report(data, filename="final_report.pdf"):
    # Determine the baseline name dynamically
    baseline_name = data["partners"][0]["name"] if (data.get("partners") and len(data["partners"]) > 0) else "Strategy Report"
    
    pdf = ReportPDF(partner_name=baseline_name)

    # 1 COVER
    add_cover(pdf, baseline_name)
    print(f"[*] PDF: Rendered Cover Page")

    # 2 EXECUTIVE SUMMARY
    pdf.add_page()
    pdf.section_title("EXECUTIVE SUMMARY")
    pdf.body_text(data.get("executive_summary", "Strategic summary pending."))
    print(f"[*] PDF: Rendered Executive Summary")

    # 3 SCORING METHODOLOGY (New Section)
    if data.get("scoring_methodology"):
        pdf.add_page()
        pdf.section_title("SCORING METHODOLOGY & FORMULA")
        pdf.body_text(data["scoring_methodology"])

    # 4 DETAILED BASELINE PROFILE
    pdf.add_page()
    pdf.section_title(f"DETAILED PROFILE: {baseline_name}")
    
    baseline_info = data["partners"][0] if data.get("partners") else {}
    if baseline_info.get("overview"):
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(13, 71, 161)
        pdf.cell(0, 10, "STRATEGIC OVERVIEW", 0, 1)
        pdf.body_text(baseline_info["overview"])
    print(f"[*] PDF: Rendered Baseline Profile")
    
    # 4. GTM STRATEGY ANALYSIS
    if data.get("gtm_strategy_analysis"):
        pdf.add_page()
        pdf.section_title("4. GO-TO-MARKET (GTM) STRATEGY COMPARISON")
        gtm = data["gtm_strategy_analysis"]
        pdf.body_text(gtm.get("summary", ""))
        
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(13, 71, 161)
        pdf.cell(0, 10, "COMPARATIVE CHANNEL STRATEGY (PARTNERS VS DIRECT):", 0, 1)
        pdf.body_text(gtm.get("channel_strategy", ""))
        
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(13, 71, 161)
        pdf.cell(0, 10, "INBOUND VS OUTBOUND DYNAMICS (STRATEGIC DELTA):", 0, 1)
        pdf.body_text(gtm.get("inbound_vs_outbound", ""))

        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(13, 71, 161)
        pdf.cell(0, 10, "COMPARATIVE ECOSYSTEM LEVERAGE:", 0, 1)
        pdf.body_text(gtm.get("ecosystem_leverage", ""))
        print(f"[*] PDF: Rendered GTM Strategy Analysis")
    
    # 5 COHORT COMPARISON matrix
    pdf.add_page()
    pdf.section_title("COMPETITIVE COHORT ANALYSIS")
    pdf.body_text(data.get("cohort", "Cohort comparison benchmarking the baseline against the identified leader group."))
    print(f"[*] PDF: Rendered Cohort Analysis")

    # 6 PERFORMANCE INDEX
    pdf.add_page()
    pdf.section_title("MARKET PERFORMANCE INDEX")
    chart_performance(data.get("partners", []), baseline_name)
    pdf.image("performance.png", x=10, w=190)
    pdf.ln(5)
    pdf.body_text(data.get("performance_index_context", "Assessment of market positioning based on cumulative scoring indices."))
    print(f"[*] PDF: Rendered Performance Index")

    # 7 STRATEGIC RADAR
    pdf.add_page()
    pdf.section_title("STRATEGIC PERFORMANCE RADAR")
    scores = data.get("scores", {})
    radar_chart(scores)
    pdf.image("radar.png", x=45, w=120)
    pdf.ln(5)
    pdf.body_text(data.get("radar_context", "Breakdown of comparative technical capabilities vs market presence."))
    print(f"[*] PDF: Rendered Strategic Radar")

    # 8 INTERPRETATION
    pdf.add_page()
    pdf.section_title("STRATEGIC INTERPRETATION")
    pdf.body_text(data.get("interpretation", "Deep-dive analysis of current performance benchmarks and evidence-based technical moats."))

    # 8.5 STRATEGIC COMPARISON TABLE
    if data.get("comparison_matrix"):
        pdf.add_page()
        pdf.section_title("STRATEGIC COMPARISON TABLE")
        
        # Header Row
        header_style = FontFace(fill_color=(22, 33, 44), color=(255, 255, 255))
        pdf.set_font("Helvetica", "B", 9)
        
        # Reset fill color to avoid leakage from section_title
        pdf.set_fill_color(255, 255, 255)
        
        with pdf.table(
            borders_layout="ALL",
            cell_fill_color=(245, 247, 250),
            cell_fill_mode="EVEN_ROWS",
            line_height=pdf.font_size * 2,
            width=190,
            col_widths=(40, 50, 50, 50)
        ) as table:
            # Header Row
            h_row = table.row()
            h_row.cell(" COMPANY", style=header_style)
            h_row.cell(" STRENGTH", style=header_style)
            h_row.cell(" WEAKNESS", style=header_style)
            h_row.cell(" FOCUS", style=header_style)

            
            # Data Rows
            pdf.set_text_color(33, 37, 41)
            pdf.set_font("Helvetica", "", 8)
            matrix = data.get("comparison_matrix", [])
            if not matrix:
                # If matrix is missing, try to build it from the partner summaries
                for p in data.get("partners", []):
                    r = table.row()
                    r.cell(clean_text(p.get('name', 'Unknown')))
                    r.cell("Capability Audit In Progress")
                    r.cell("Market Gap Analysis Pending")
                    r.cell(clean_text(p.get('industries', ['General'])[0] if p.get('industries') else 'General'))
            else:
                for row_data in matrix: # Removed the [:10] limit
                    r = table.row()
                    r.cell(clean_text(row_data.get('Company', row_data.get('partner_name', 'Partner'))))
                    r.cell(clean_text(row_data.get('Strength', 'Capability Audit Pending')))
                    r.cell(clean_text(row_data.get('Weakness', 'Minimal Disclosure')))
                    r.cell(clean_text(row_data.get('Market_Focus', 'General Markets')))
        print(f"[*] PDF: Rendered Comparison Table")


    # 9 LEADERS DEEP-DIVE
    pdf.add_page()
    pdf.section_title("COMPETITOR DEEP-DIVE: STRENGTHS & GAPS")
    leaders = data.get("leaders", [])
    if not leaders:
        pdf.body_text("Comparative leader audit in progress. The current cohort is being benchmarked against global industry averages.")
    else:
        for leader in leaders:
            name = leader.get('name', 'Competitor').upper()
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(13, 71, 161)
            pdf.cell(0, 10, f">> {name}", 0, 1)
            
            # Label Above Value for safety
            pdf.set_font("Helvetica", "B", 10)
            pdf.set_text_color(70, 70, 70)
            pdf.cell(0, 6, "PRIMARY STRENGTH:", 0, 1)
            pdf.set_font("Helvetica", "", 10)
            pdf.set_text_color(33, 37, 41)
            pdf.multi_cell(0, 6, clean_text(leader.get('strength', 'Analysis pending source validation.')))
            pdf.ln(2)
            
            pdf.set_font("Helvetica", "B", 10)
            pdf.set_text_color(70, 70, 70)
            pdf.cell(0, 6, "IDENTIFIED GAP / WEAKNESS:", 0, 1)
            pdf.set_font("Helvetica", "", 10)
            pdf.set_text_color(33, 37, 41)
            pdf.multi_cell(0, 6, clean_text(leader.get('weakness', 'No significant gap identified in public data.')))
            pdf.ln(2)
            
            pdf.set_font("Helvetica", "I", 9)
            pdf.set_text_color(100, 100, 100)
            evidence = leader.get('evidence', 'General market data audit')
            pdf.multi_cell(0, 6, f"SOURCE EVIDENCE: {evidence}")
            pdf.ln(8)
        print(f"[*] PDF: Rendered Competitor Deep-Dive")

    # 10 GAP ANALYSIS
    pdf.add_page()
    pdf.section_title("GAP ANALYSIS & VULNERABILITIES")
    pdf.image("gap.png", x=20, w=170)
    pdf.ln(5)
    pdf.body_text(data.get("gap", "Assessment of baseline vulnerabilities based on identified market deltas."))
    print(f"[*] PDF: Rendered Gap Analysis")

    # 11 RECOMMENDATIONS
    pdf.add_page()
    pdf.section_title("ACTIONABLE RECOMMENDATIONS")
    
    recs = data.get("recommendations", [])
    if not recs:
        pdf.body_text("Strategic recommendations are being modeled based on current performance indices.")
    else:
        for i, r in enumerate(recs[:4]):
            pdf.set_font("Helvetica", "B", 11)
            pdf.set_text_color(13, 71, 161)
            pdf.cell(0, 8, f"{i+1}. {r.get('title', 'Recommendation').upper()}", 0, 1)
            
            pdf.set_font("Helvetica", "I", 10)
            pdf.set_text_color(50, 50, 50)
            pdf.multi_cell(0, 6, f"Rationale: {clean_text(r.get('rationale', ''))}")
            
            pdf.ln(1)
            pdf.set_x(pdf.l_margin)  # Reset to left margin after multi_cell
            pdf.set_font("Helvetica", "B", 10)
            pdf.set_text_color(70, 70, 70)
            pdf.cell(0, 6, "IMPLEMENTATION STEPS:", 0, 1)
            pdf.set_font("Helvetica", "", 10)
            pdf.set_text_color(33, 37, 41)
            
            steps = r.get('implementation_steps', [])
            if isinstance(steps, list):
                for step in steps:
                    pdf.set_x(20)
                    pdf.multi_cell(180, 6, f"- {clean_text(str(step))}")
            else:
                pdf.set_x(pdf.l_margin)
                pdf.multi_cell(0, 6, clean_text(str(steps)))
            pdf.ln(4)
        print(f"[*] PDF: Rendered Recommendations")

    # 12 PATH TO DOMINANCE (Roadmap)
    pdf.add_page()
    pdf.section_title("12-MONTH STRATEGIC ROADMAP")
    path_data = data.get("path", "")
    if isinstance(path_data, list) and len(path_data) > 0:
        for item in path_data:
            if isinstance(item, dict):
                pdf.set_font("Helvetica", "B", 11)
                pdf.set_text_color(13, 71, 161)
                pdf.cell(0, 8, clean_text(item.get("quarter", "Next Phase")), 0, 1)
                
                pdf.set_font("Helvetica", "B", 10)
                pdf.set_text_color(33, 37, 41)
                pdf.cell(30, 6, "MILESTONE:", 0, 0)
                pdf.set_font("Helvetica", "", 10)
                pdf.cell(0, 6, clean_text(item.get("milestone", "Objective alignment")), 0, 1)
                
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(30, 6, "CAPABILITIES:", 0, 0)
                pdf.set_font("Helvetica", "", 10)
                pdf.cell(0, 6, clean_text(item.get("capabilities", "Resource allocation")), 0, 1)
                
                details = item.get("details", [])
                if isinstance(details, list):
                    pdf.set_font("Helvetica", "I", 9)
                    for d in details:
                        pdf.set_x(20) # Explicitly set X for indentation
                        pdf.multi_cell(180, 5, f"> {clean_text(str(d))}")
                pdf.ln(5)
        print(f"[*] PDF: Rendered Strategic Roadmap")
    else:
        pdf.body_text(str(path_data) if path_data else "12-month development roadmap modeling in progress.")

    # 13 PRODUCT BENCHMARKING
    if data.get("product_benchmarking"):
        pdf.add_page()
        pdf.section_title("PRODUCT & SOLUTION BENCHMARKING")
        
        # Restore bar chart
        chart_solutions(data["product_benchmarking"], baseline_name)
        if os.path.exists("solutions.png"):
            pdf.image("solutions.png", x=10, w=190)
            pdf.ln(5)
            pdf.body_text("Comparison of core products and solutions identified across the leader cohort, focusing on efficiency and technical complexity.")
            pdf.ln(5)
        
        # Using fpdf2 table for automatic wrapping
        header_style = FontFace(fill_color=(22, 33, 44), color=(255, 255, 255))
        pdf.set_font("Helvetica", "B", 9)
        prods = data["product_benchmarking"]
        
        with pdf.table(
            borders_layout="ALL",
            cell_fill_color=(240, 244, 248),
            cell_fill_mode="ROWS",
            line_height=pdf.font_size * 2,
            width=190,
            col_widths=(50, 70, 50, 20)
        ) as table:
            # Header Row
            h_row = table.row()
            h_row.cell(" PARTNER", style=header_style)
            h_row.cell(" SOLUTION", style=header_style)
            h_row.cell(" VERTICAL", style=header_style)
            h_row.cell(" EFF.", style=header_style)

            
            pdf.set_text_color(33, 37, 41)
            pdf.set_font("Helvetica", "", 8)
            if not prods:
                table.row().cell("  (Product landscape audit in progress - specific solution mapping pending)", colspan=4)
            else:
                last_partner = None
                for prod in prods[:15]:
                    r = table.row()
                    current_partner = prod.get('partner_name', 'N/A')
                    
                    # Suppress repeated partner names for a cleaner grouped look
                    if current_partner == last_partner:
                        r.cell("") 
                    else:
                        r.cell(clean_text(current_partner))
                        last_partner = current_partner
                        
                    r.cell(clean_text(prod.get('solution_identified', 'N/A')))
                    r.cell(clean_text(prod.get('target_vertical', 'N/A')))
                    r.cell(f"{prod.get('efficiency_score', '0')}%")
        print(f"[*] PDF: Rendered Product Benchmarking Section")
    else:
        print(f"[!] PDF Warning: Skipping Product Benchmarking (data missing)")

    
    pdf.ln(5)
    pdf.body_text("FINAL STRATEGIC INSIGHT:")
    pdf.set_font("Helvetica", "I", 11)
    final_insight = data.get("final_insight", data.get("Final_insight", "Strategy finalized."))
    pdf.multi_cell(0, 7, clean_text(final_insight), align='J')

    output_dir = "trigya report"
    if not os.path.exists(output_dir): os.makedirs(output_dir)
    
    # 1. Prepare global report path with timestamp
    from datetime import datetime
    base, ext = os.path.splitext(filename)
    if not ext: ext = ".pdf"
    date_str = datetime.now().strftime("%d-%m-%Y_%H%M%S")
    final_filename = f"{base}_{date_str}{ext}"
    global_path = os.path.join(output_dir, final_filename)
    
    # Save to global folder
    pdf.output(global_path)
    print(f"[*] PREMIUM STRATEGIC PDF report saved to Global Bank: {global_path}")
    
    # 2. Save a copy to the baseline company folder as requested
    try:
        # Re-derive the safe folder name for the baseline
        clean_name = baseline_name.lower()
        for suffix in ['.com', '.co.in', '.in', '.org', '.net', '.co', '.io', '.ai']:
            if clean_name.endswith(suffix):
                clean_name = clean_name[:-len(suffix)]
                break
        safe_name = re.sub(r'[^\w\s-]', '', clean_name).strip().title().replace(' ', '_')
        
        baseline_reports_dir = os.path.join("scraped_data", safe_name, "reports")
        if not os.path.exists(baseline_reports_dir):
            os.makedirs(baseline_reports_dir)
            
        company_report_path = os.path.join(baseline_reports_dir, final_filename)
        
        # Save another copy
        pdf.output(company_report_path)
        print(f"[+] Backup copy synced to Baseline folder: {company_report_path}")
    except Exception as e:
        print(f"[-] Failed to save backup copy to baseline folder: {e}")

    return global_path

# =========================
# BRIDGE FUNCTIONS FOR MAIN.PY
# =========================

def save_partner_data(data: dict):
    """Saves partner data to TXT and JSON files inside a company-specific folder."""
    base_output_dir = "scraped_data"
    partner_name = data.get('name', 'Unknown')
    partner_id = data.get('partner_id', 'no_id')
    parent_company = data.get('parent_company') # Optional parent for competitor nesting
    
    # --- Refine Name for Folder ---
    # 1. Strip common URL suffixes if the name looks like a domain
    clean_name = partner_name.lower()
    for suffix in ['.com', '.co.in', '.in', '.org', '.net', '.co', '.io', '.ai']:
        if clean_name.endswith(suffix):
            clean_name = clean_name[:-len(suffix)]
            break
            
    # 2. Remove generic prefixes like "Premium Zoho Partner in"
    clean_name = re.sub(r'^premium zoho partner in ', '', clean_name, flags=re.I)
    
    # 3. Final sanitization
    safe_name = re.sub(r'[^\w\s-]', '', clean_name).strip().title().replace(' ', '_')
    if not safe_name: safe_name = "Unknown_Company"
    
    # Create the company folder
    # --- INTELLIGENT PATH RESOLUTION ---
    # We prioritize the EXPLICIT parent_company request from the dashboard.
    # If no parent is provided (like during a Sync), we search for an existing folder.
    
    company_dir = None
    
    if parent_company:
        # User explicitly wants this as a competitor
        safe_parent = re.sub(r'[^\w\s-]', '', parent_company).strip().title().replace(' ', '_')
        company_dir = os.path.join(base_output_dir, safe_parent, "competitors", safe_name)
        data["relationship"] = {
            "type": "competitor",
            "parent_company": parent_company,
            "folder_path": f"{safe_parent}/competitors/{safe_name}"
        }
        print(f"[*] Mapping as competitor to: {parent_company}")
    else:
        # No parent requested, check if it already exists anywhere (for Sync/Updates)
        if partner_id and partner_id != "no_id":
            import glob
            pattern = os.path.join(base_output_dir, "**", f"*_{partner_id}.json")
            matches = glob.glob(pattern, recursive=True)
            if matches:
                company_dir = os.path.dirname(matches[0])
                print(f"[*] Found existing path for ID {partner_id}: {company_dir}")

    # Fallback to primary folder if no parent requested and no existing folder found
    if not company_dir:
        company_dir = os.path.join(base_output_dir, safe_name)
        data["relationship"] = {
            "type": "parent",
            "parent_company": None,
            "folder_path": safe_name
        }

    # --- DATA MERGING & SAFETY ---
    # Load existing data if it exists to preserve metadata and protect against scrape failures
    existing_data = {}
    json_path = None
    if os.path.exists(company_dir):
        existing_files = [f for f in os.listdir(company_dir) if f.endswith(f"_{partner_id}.json")]
        if existing_files:
            json_path = os.path.join(company_dir, existing_files[0])
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
            except: pass

    # 1. Safety: Do not overwrite a good name with "Unknown Partner" if scrape failed
    if partner_name == "Unknown Partner" and existing_data.get('name') and existing_data.get('name') != "Unknown Partner":
        partner_name = existing_data['name']
        data['name'] = partner_name
        print(f"[*] Safety: Restored name '{partner_name}' from existing data.")

    # 2. Safety: Do not overwrite a good overview with empty/null if scrape failed
    if (not data.get('overview') or "Content extraction failed" in data.get('overview', '')) and existing_data.get('overview'):
        data['overview'] = existing_data['overview']
        print(f"[*] Safety: Preserved existing overview for '{partner_name}'.")

    # 3. Persistence: Always keep the parent_company if we already have one (and no new one was provided)
    if not parent_company and existing_data.get('parent_company'):
        parent_company = existing_data['parent_company']
        data['parent_company'] = parent_company
        print(f"[*] Persistence: Preserved parent '{parent_company}' from existing data.")

    # 4. Comprehensive Section Merging (Blogs, Cases, Stories)
    # If the new scrape found 0 items but the old data had items, KEEP the old items.
    for key in ['blogs', 'case_studies', 'customer_stories']:
        new_items = data.get(key, [])
        old_items = existing_data.get(key, [])
        if not new_items and old_items:
            data[key] = old_items
            print(f"[*] Safety: Preserved {len(old_items)} {key} for '{partner_name}' (new scrape returned 0).")

    if not os.path.exists(company_dir):
        os.makedirs(company_dir)
        
    # --- FILENAME PERSISTENCE ---
    filename_base = f"{safe_name}_{partner_id}"
    if json_path:
        filename_base = os.path.basename(json_path).replace(".json", "")
    elif partner_id and partner_id != "no_id":
        existing_files = [f for f in os.listdir(company_dir) if f.endswith(f"_{partner_id}.json")]
        if existing_files:
            filename_base = existing_files[0].replace(".json", "")

    # Generate JSON
    json_path = os.path.join(company_dir, f"{filename_base}.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    # Generate TXT (Detailed version)
    txt_path = os.path.join(company_dir, f"{filename_base}.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("="*60 + "\n")
        f.write(f"COMPANY: {partner_name}\n")
        f.write(f"ID     : {partner_id}\n")
        f.write(f"WEBSITE: {data.get('website', 'N/A')}\n")
        f.write(f"LINKEDIN: {data.get('linkedin', 'N/A')}\n")
        f.write(f"PARENT : {parent_company or 'None'}\n")
        f.write("="*60 + "\n\n")
        
        f.write(f"OVERVIEW:\n{'-'*60}\n{data.get('overview','')}\n\n")
        
        if data.get("analysis_summary"):
            f.write(f"AI ANALYSIS SUMMARY:\n{'-'*60}\n{data['analysis_summary']}\n\n")

        # Sections for blogs, cases, stories
        for label, key in [("BLOGS", "blogs"), ("CASE STUDIES", "case_studies"), ("CUSTOMER STORIES", "customer_stories")]:
            items = data.get(key, [])
            f.write(f"{label} ({len(items)} found):\n")
            f.write("="*60 + "\n")
            if not items:
                f.write("  (none found)\n\n")
            else:
                for i, item in enumerate(items, 1):
                    f.write(f"  [{i}] {item.get('title', 'Untitled')}\n")
                    f.write(f"      Link: {item.get('link', 'N/A')}\n")
                    content = item.get('content', '').strip()
                    if content and content != "Content extraction failed." and "skipping direct content extraction" not in content:
                        f.write(f"      Content:\n")
                        formatted = format_content_for_txt(content)
                        f.write(formatted + "\n")
                    else:
                        f.write("      Content: (not available)\n")
                    f.write("\n")
                f.write("\n")
        
        # Social Media
        sm = data.get("social_media", {})
        if sm:
            f.write("SOCIAL MEDIA LINKS:\n")
            f.write("="*60 + "\n")
            for platform, details in sm.items():
                if details:
                    url = details.get("url") if isinstance(details, dict) else details
                    f.write(f"  {platform.title()}: {url}\n")
            f.write("\n")

    # --- API Sync Integration ---
    webhook_url = os.getenv("API_WEBHOOK_URL")
    if webhook_url:
        send_to_webhook(data, webhook_url)

    return txt_path

def send_to_webhook(data: dict, url: str):
    """Sends the scraped data to an external API webhook with authentication."""
    try:
        api_key = os.getenv("API_WEBHOOK_KEY", "")
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": api_key
        }
        
        print(f"[*] Syncing data for '{data.get('name')}' to API: {url}...", file=sys.stderr)
        # We send the full JSON data object
        response = requests.post(url, json=data, headers=headers, timeout=15)
        
        if response.status_code in [200, 201]:
            print(f"[+] API Sync Successful: {response.status_code}", file=sys.stderr)
        else:
            print(f"[-] API Sync Failed: Status {response.status_code} - {response.text[:100]}", file=sys.stderr)
    except Exception as e:
        print(f"[-] API Sync Error: {e}", file=sys.stderr)

def save_report(content: str, filename: str):
    """Saves raw text report."""
    output_dir = "trigya report"
    if not os.path.exists(output_dir): os.makedirs(output_dir)
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path

def save_report_as_pdf(content: str, filename: str, partners_data: list = None):
    """Bridge to the new generate_report function with robust JSON cleaning."""
    try:
        # Robust JSON cleaning (remove markdown wrapping)
        json_str = content.strip()
        if "```json" in json_str:
            json_str = json_str.split("```json")[1].split("```")[0].strip()
        elif "```" in json_str:
            json_str = json_str.split("```")[1].split("```")[0].strip()
            
        report_data = json.loads(json_str)
        
        # ALWAYS refresh/add partners data locally for stability (32 partners is too much for AI JSON)
        if partners_data:
            report_data["partners"] = []
            for i, p in enumerate(partners_data):
                blogs = len(p.get('blogs', []))
                cases = len(p.get('case_studies', [])) + len(p.get('customer_stories', []))
                # Smart weighted scoring
                p_entry = {
                    "name": p.get('name', 'Unknown'),
                    "scores": {
                        "technical_depth": min(85, blogs * 6 + 30),
                        "customer_success": min(85, cases * 8 + 30),
                        "market_authority": 40
                    }
                }
                # Keep full content for the baseline (first partner) to show in report
                if i == 0:
                    p_entry["overview"] = p.get("overview", "")
                    p_entry["blogs"] = p.get("blogs", [])
                    p_entry["case_studies"] = p.get("case_studies", [])
                    p_entry["customer_stories"] = p.get("customer_stories", [])
                
                report_data["partners"].append(p_entry)
        
        return generate_report(report_data, filename=filename)
    except Exception as e:
        import traceback
        print(f"[-] AI JSON Parsing Error: {e}")
        traceback.print_exc()
        # Final emergency fallback - Still use professional PDF class
        pdf = ReportPDF(partner_name=filename.split('_')[0])
        pdf.add_page()
        pdf.section_title("STRATEGIC ANALYSIS (DATA FALLBACK)")
        pdf.body_text("The following analysis was captured during a high-load strategic cycle. " + 
                      "While the visual index is processing, the core intelligence is presented below.")
        pdf.body_text(content)
        
        output_dir = "trigya report"
        if not os.path.exists(output_dir): os.makedirs(output_dir)
        path = os.path.join(output_dir, filename)
        pdf.output(path)
        return path