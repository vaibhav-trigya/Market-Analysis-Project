import sys
import re
import os
from urllib.parse import urljoin, urlparse
from pypdf import PdfReader

def minify_text(text: str) -> str:
    """Collapses multiple spaces but preserves newlines and tabs as requested."""
    if not text: return ""
    # Remove literal spaces at the end of lines or before tabs
    text = re.sub(r' +(?=\n)', '', text)
    text = re.sub(r' +(?=\t)', '', text)
    # Remove literal spaces at the start of lines or after tabs
    text = re.sub(r'(?<=\n) +', '', text)
    text = re.sub(r'(?<=\t) +', '', text)
    # Collapse multiple literal spaces into one
    text = re.sub(r' {2,}', ' ', text)
    return text.strip()


# ------------------------------------------------------------------ #
# Zoho Profile Extraction Functions (unchanged from original)
# ------------------------------------------------------------------ #

def extract_name(agent) -> str | None:
    # Generic words that are likely NOT the company name itself
    LOCATIONS = ["india", "usa", "uk", "united states", "united kingdom", "australia", "canada", "singapore", "dubai", "london", "new york"]
    GENERICS = ["zoho consultant", "zoho partner", "welcome to", "home page", "about us", "contact us", "services"]
    
    # 1. Try specific partner selectors first
    selectors = [
        "h1.partner-name", "h1.partnerProfile__name",
        ".partner-profile h1", ".partnerCard__name",
        "a.navbar-brand", ".logo img[alt]", "img.logo[alt]"
    ]
    for sel in selectors:
        if "[alt]" in sel:
            base_sel = sel.split("[alt]")[0]
            try:
                el = agent.page.query_selector(base_sel)
                if el:
                    val = el.get_attribute("alt")
                    if val and len(val) > 1 and len(val) < 40:
                        lower_val = val.lower().strip()
                        if lower_val not in LOCATIONS and not any(g in lower_val for g in GENERICS):
                            return val.strip()
            except: pass
        else:
            val = agent._safe_text(sel)
            if val and (sel != "h1" or len(val) < 35):
                lower_val = val.lower().strip()
                if lower_val not in LOCATIONS and not any(generic in lower_val for generic in GENERICS):
                    return val.strip()
                
    # 2. Try page title cleaning
    try:
        title = agent.page.title()
        if title:
            # If we have a target name, look for the part that contains it
            search_target = agent.partner_name.lower() if agent.partner_name else ""
            
            for sep in ['|', '-', '—', ':']:
                if sep in title:
                    parts = [p.strip() for p in title.split(sep)]
                    # Priority 1: Part that contains our search target
                    if search_target:
                        for p in parts:
                            if search_target in p.lower() and len(p) < 40:
                                return p
                    
                    # Priority 2: Use the part that isn't a generic location
                    for p in parts:
                        low_p = p.lower()
                        if len(p) > 1 and len(p) < 35 and low_p not in LOCATIONS and not any(g in low_p for g in GENERICS):
                            return p
                            
            if len(title) < 40:
                lower_title = title.lower()
                if lower_title not in LOCATIONS and not any(generic in lower_title for generic in GENERICS):
                    return title.strip()
    except: pass

    return agent.partner_name or "Unknown Partner"


def extract_overview(agent) -> str | None:
    selectors = [
        ".partner-overview", ".partnerProfile__overview",
        ".about-partner p", ".partner-description",
        "[class*='overview']", "[class*='description'] p",
        ".partner-about", "section.about p", "#overview", "#about",
        ".hero__content", ".hero-text", "main p", ".content p"
    ]
    for sel in selectors:
        val = agent._safe_text(sel)
        if val and len(val) > 20:
            return minify_text(val)
            
    # Try meta description
    try:
        meta_desc = agent.page.locator("meta[name='description']").get_attribute("content")
        if meta_desc and len(meta_desc) > 20:
            return minify_text(meta_desc)
    except Exception: pass

    # Fallback to any significant paragraph
    for para in agent.page.query_selector_all("p"):
        try:
            text = para.inner_text().strip()
            if len(text) > 60: # Reduced from 80
                return minify_text(text)
        except Exception:
            continue
    return None


def extract_website(agent) -> str | None:
    website_selectors = [
        "a.zwc-pr-weblink", "a[href*='visit'][class*='website' i]",
        "a.partner-website", "a[class*='website']",
    ]
    for sel in website_selectors:
        href = agent._safe_attr(sel, "href")
        if href:
            return agent._absolute_url(href)
    for anchor in agent.page.query_selector_all("a[href]"):
        try:
            href = anchor.get_attribute("href") or ""
            text = anchor.inner_text().strip().lower()
            if (
                href.startswith("http")
                and "zoho.com" not in href
                and "linkedin.com" not in href
                and "twitter.com" not in href
                and "facebook.com" not in href
                and ("website" in text or "visit" in text or "www" in href)
            ):
                return href
        except Exception:
            continue
    return None


def extract_linkedin(agent) -> str | None:
    ln_el = agent.page.query_selector("a.zwc-pr-linkedin")
    if ln_el:
        href = ln_el.get_attribute("href")
        if href:
            return agent._absolute_url(href)
            
    # Fallback: Search for any LinkedIn link on the page, excluding Zoho's corporate links
    for anchor in agent.page.query_selector_all("a[href*='linkedin.com']"):
        try:
            href = anchor.get_attribute("href")
            if href:
                abs_url = agent._absolute_url(href)
                # Filter out known Zoho corporate LinkedIn profiles
                if abs_url and not any(x in abs_url.lower() for x in ["zoho-partner-program", "company/zoho", "/zoho"]):
                    return abs_url
        except Exception:
            continue
    return None


def extract_linkedin_from_external(agent, website_url: str) -> str | None:
    """Attempt to find a LinkedIn link on the partner's own website."""
    print(f"[*] Attempting to find LinkedIn on {website_url}...", file=sys.stderr)
    try:
        # We assume the page is already loaded or we load it
        if agent.page.url != website_url:
            agent._safe_goto(website_url, timeout=45000)
            agent.page.wait_for_timeout(2000)
        
        # Check footer and header specifically first
        containers = agent.page.locator("footer, header, .footer, .header, .social").all()
        for container in containers:
            ln_link = container.locator("a[href*='linkedin.com']").first
            if ln_link.count() > 0:
                href = ln_link.get_attribute("href")
                if href and "linkedin.com/company/" in href:
                    return href
        
        # General search on the page
        anchors = agent.page.locator("a[href*='linkedin.com/company/']").all()
        for a in anchors:
            href = a.get_attribute("href")
            if href: return href
            
    except Exception as e:
        print(f"[*] Warning: External LinkedIn extraction failed: {e}", file=sys.stderr)
    return None



def extract_customer_stories(agent) -> list:
    print("[*] Switching to Customer Stories tab...", file=sys.stderr)
    try:
        tab_selectors = [
            "text='Customer Stories'",
            "li:has-text('Customer Stories')",
            "div:has-text('Customer Stories')"
        ]
        tab_clicked = False
        for sel in tab_selectors:
            tab = agent.page.locator(sel).first
            if tab.count() > 0:
                tab.click()
                tab_clicked = True
                break
        if tab_clicked:
            agent.page.wait_for_timeout(4000)
            agent._scroll_to_bottom()

        results = []
        # 1. Try specific patterns and general cards inside the tab
        story_links = agent.page.locator(
            "a[href*='/customers/'], a[href*='FileDownloadPublic'], a[href*='customer-story'], "
            ".zp-customer-stories-tab-content a, .customer-stories a, .story-card a, .case-study-card a, "
            ".zwc-tab-section.active a, .zwc-pr-tab-content.active a"
        ).all()
        for link in story_links:
            try:
                href = link.get_attribute("href")
                title = link.inner_text().strip()
                if not title:
                    title = link.locator("xpath=..").inner_text().split("\n")[0].strip()
                if title and href and len(title) > 3:
                    item = {"title": title, "link": agent._absolute_url(href), "detected_type": "customer_stories"}
                    if item not in results:
                        results.append(item)
            except Exception:
                continue

        if not results:
            containers = agent.page.locator(
                ".zp-customer-stories-tab-content, .zwc-pr-customer-stories, .customer-stories, .zp-tab-panel:not(.hide), .zwc-tab-section.active, .zwc-casestudy-sec"
            ).all()
            for container in containers:
                anchors = container.locator("a").all()
                for a in anchors:
                    item = agent._anchor_to_item(a)
                    if item:
                        item["detected_type"] = "customer_stories"
                        if item not in results:
                            results.append(item)
        
        # 3. Final fallback: look for card-like elements in the whole page if tab was clicked
        if not results and tab_clicked:
             cards = agent.page.locator("[class*='customer-story' i], [class*='testimonial' i]").all()
             for card in cards:
                 anchors = card.locator("a").all()
                 for a in anchors:
                     item = agent._anchor_to_item(a)
                     if item:
                         item["detected_type"] = "customer_stories"
                         if item not in results:
                             results.append(item)

        return results
    except Exception as e:
        print(f"[*] Warning: Error in extract_customer_stories: {e}", file=sys.stderr)
    
    results = agent._extract_items_from_section(
        ["customer stor", "testimonial", "success stor", "client stor"]
    )
    for item in results:
        item["detected_type"] = "customer_stories"
    return results


def extract_blogs(agent) -> list:
    try:
        tab = agent.page.locator(
            "ul.zwc-pr-tab li:has-text('Blog'), li:has-text('Blogs')"
        ).first
        if tab.count() > 0:
            tab.click()
            agent.page.wait_for_timeout(2000)
            results = []
            anchors = agent.page.locator(
                ".zwc-pr-tab-content.active a, .zwc-pr-blog-list a"
            ).all()
            for a in anchors:
                item = agent._anchor_to_item(a)
                if item:
                    item["detected_type"] = "blogs"
                    results.append(item)
            if results:
                return results
    except Exception:
        pass
    results = agent._extract_items_from_section(["blog", "article", "post"])
    for item in results:
        item["detected_type"] = "blogs"
    return results


def extract_case_studies(agent) -> list:
    print("[*] Switching to Case Studies tab...", file=sys.stderr)
    try:
        tab_selectors = ["a:has-text('Case Studies')", "li:has-text('Case Studies')"]
        tab_clicked = False
        for sel in tab_selectors:
            tab = agent.page.locator(sel).first
            if tab.count() > 0:
                try:
                    tab.click(timeout=5000)
                    tab_clicked = True
                    break
                except Exception: continue

        if tab_clicked:
            agent.page.wait_for_timeout(3000)
            agent._scroll_to_bottom()
            results = []
            anchors = agent.page.locator(".zwc-pr-tab-content.active a, .zwc-tab-section.active a").all()
            for a in anchors:
                item = agent._anchor_to_item(a)
                if item:
                    item["detected_type"] = "case_studies"
                    results.append(item)
            if results:
                return results
    except Exception:
        pass

    results = _extract_by_class_or_id(agent, ["case-stud", "casestud", "case_stud", "success-stor"])
    if results:
        for item in results:
            item["detected_type"] = "case_studies"
        return results
    
    results = agent._extract_items_from_section(["case stud", "case-stud"])
    for item in results:
        item["detected_type"] = "case_studies"
    return results


def _extract_by_class_or_id(agent, keywords: list[str]) -> list[dict]:
    results = []
    try:
        agent.page.evaluate("""
            () => {
                const potentialCards = document.querySelectorAll('div, section, article, li');
                potentialCards.forEach(el => {
                    const classStr = el.className && typeof el.className === 'string'
                        ? el.className.toLowerCase() : '';
                    if (classStr.includes('card') || classStr.includes('item') ||
                        classStr.includes('study') || classStr.includes('post')) {
                        el.dispatchEvent(new MouseEvent('mouseover', {
                            view: window, bubbles: true, cancelable: true
                        }));
                    }
                });
            }
        """)
        agent.page.wait_for_timeout(1000)

        items = agent.page.evaluate(f"""
            (keywords) => {{
                const results = [];
                document.querySelectorAll('*').forEach(el => {{
                    const classStr = el.className && typeof el.className === 'string'
                        ? el.className.toLowerCase() : '';
                    const idStr = el.id ? el.id.toLowerCase() : '';
                    if (keywords.some(kw => classStr.includes(kw) || idStr.includes(kw))) {{
                        // Anti-Mixing Check: If we found a 'case study' class but the heading says 'Customer Stories', skip it.
                        const heading = el.querySelector('h1,h2,h3,h4,h5,h6, [class*="title" i], [class*="heading" i]');
                        const hText = heading ? heading.innerText.toLowerCase() : '';
                        if (keywords.some(k => k.includes('case')) && hText.includes('customer stor')) return;
                        if (keywords.some(k => k.includes('customer')) && hText.includes('case stud')) return;

                        if (el.tagName === 'A') {{
                            results.push({{ title: el.innerText.trim(), link: el.href }});
                        }} else {{
                            el.querySelectorAll('a').forEach(a => {{
                                let aText = a.innerText.trim();
                                const href = a.href;
                                if (aText.toLowerCase().includes('read more') ||
                                    aText.toLowerCase().includes('view more') ||
                                    aText.length < 3) {{
                                    if (heading) aText = heading.innerText.trim();
                                    else if (el.innerText.trim().length > 10)
                                        aText = el.innerText.split('\\n')[0].trim();
                                }}
                                if (aText.length > 2) results.push({{ title: aText, link: href }});
                            }});
                        }}
                    }}
                }});
                return results;
            }}
        """, keywords)

        for item in items:
            if item.get("link"):
                abs_url = agent._absolute_url(item["link"])
                if abs_url and abs_url.startswith("http"):
                    results.append({"title": item["title"], "link": abs_url})
            elif item.get("content"):
                results.append(item)
    except Exception as e:
        print(f"[*] Warning: Error in _extract_by_class_or_id: {e}", file=sys.stderr)
    return results


def _try_extract_pdf(path: str) -> str | None:
    try:
        reader = PdfReader(path)
        if reader.is_encrypted:
            print(f"[*] PDF is encrypted/password-protected, skipping.", file=sys.stderr)
            return None
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text.strip() if len(text.strip()) > 50 else None
    except Exception as e:
        print(f"[*] PDF read error: {e}", file=sys.stderr)
        return None


def extract_page_content(agent, url: str) -> str | None:
    print(f"[*] Fetching content from: {url}", file=sys.stderr)
    is_download_url = any(p in url.lower() for p in [
        "filedownload", "store.zoho.com", ".pdf", "/download", "file_id="
    ])

    if is_download_url:
        temp_path = os.path.join(os.getcwd(), "temp_scraper_dl.pdf")
        try:
            with agent.page.expect_download(timeout=30000) as dl_info:
                try:
                    agent._safe_goto(url, timeout=45000)
                except Exception as e:
                    if "Download is starting" not in str(e) and "net::ERR" not in str(e):
                        raise e
            download = dl_info.value
            if download:
                download.save_as(temp_path)
                text = _try_extract_pdf(temp_path)
                if text:
                    return text
                print(f"[*] Downloaded file is not a readable PDF.", file=sys.stderr)
                return None
        except Exception as e:
            print(f"[*] Download failed for {url}: {e}", file=sys.stderr)
            return None
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    try:
        # Use domcontentloaded + fixed wait to avoid networkidle hangs on Zoho tracking scripts
        agent._safe_goto(url, timeout=60000)
        agent.page.wait_for_timeout(5000) # Give extra time for JS content and layout
        
        content = agent.page.evaluate("""
            () => {
                // Specialized handling for YouTube
                if (window.location.href.includes('youtube.com/watch')) {
                    const desc = document.querySelector('#description-inline-expander');
                    if (desc) return desc.innerText.trim();
                    const snippet = document.querySelector('yt-formatted-string#description-text');
                    if (snippet) return snippet.innerText.trim();
                }

                const excludes = [
                    'nav','footer','header','aside','.navbar','.footer','.header',
                    '.menu','.sidebar','.ad','.ads','.social-share','.related-posts',
                    '#navbar','#footer','#header','.top-bar','.bottom-bar',
                    '.cookie-banner', '.gdpr', '.banner-ad',
                    'script','style','iframe','noscript','svg','button','[role="button"]'
                ];
                
                const clone = document.body.cloneNode(true);
                excludes.forEach(selector => {
                    clone.querySelectorAll(selector).forEach(el => el.remove());
                });

                // Priority containers for main content
                const mainSelectors = [
                    'article', 'main', '.post-content', '.blog-content',
                    '.entry-content', '.content', '#content', '.article-body',
                    '.case-study-content', '.zp-customer-story-content',
                    '.elementor-widget-theme-post-content', '.elementor-widget-container', 
                    '.elementor-text-editor', '.entry-content-single',
                    '.zpblog-post-content', '.zpcontent', '.zptext',
                    '.zpcontent-container', '.theme-content-area-inner', '.theme-content-container'
                ];
                
                // Aggregation Strategy:
                // 1. Try to find the best container and collect all text from its relevant children
                // 2. If no single best container, aggregate all elements matching main selectors
                
                let aggregatedContent = [];
                let seenTexts = new Set();

                // Try each selector and collect all matching elements
                for (const selector of mainSelectors) {
                    const elements = clone.querySelectorAll(selector);
                    elements.forEach(el => {
                        // Check if this element is nested inside an already collected one
                        let isNested = false;
                        for (let other of elements) {
                            if (other !== el && other.contains(el)) {
                                isNested = true;
                                break;
                            }
                        }
                        if (isNested) return;

                        const text = el.innerText.trim();
                        if (text.length > 50 && !seenTexts.has(text)) {
                            aggregatedContent.push(text);
                            seenTexts.add(text);
                        }
                    });
                    
                    // If we found significant content with a high-priority selector, stop and use it
                    const totalLen = aggregatedContent.join('\\n\\n').length;
                    if (totalLen > 300) break; 
                }
                
                if (aggregatedContent.length > 0) {
                    const result = aggregatedContent.join('\\n\\n');
                    if (result.length > 100) return result;
                }

                // Fallback: Paragraphs aggregation
                const paragraphs = Array.from(clone.querySelectorAll('p, .zptext, div.zprow'));
                if (paragraphs.length > 0) {
                    const pText = paragraphs
                        .map(p => p.innerText.trim())
                        .filter(t => t.length > 25)
                        .join('\\n\\n');
                    if (pText.length > 100) return pText;
                }

                // Final Fallback: Body text
                const bodyText = clone.innerText.trim();
                if (bodyText.length > 80) return bodyText;

                return null;
            }
        """)
        return minify_text(content) if content and len(content) > 30 else None
    except Exception as e:
        print(f"[*] Warning: Could not extract content from {url}: {e}", file=sys.stderr)
        return None



# ------------------------------------------------------------------ #
# IMPROVED: External Website Extraction
# ------------------------------------------------------------------ #

# Keywords used for categorisation (shared between nav scan & article scan)
BLOG_URL_KW  = ["/blog", "/blogs", "/article", "/articles", "/insight",
                "/insights", "/news", "/post", "/posts", "/updates", "/press",
                "blog-post", "news-item"]
CASE_URL_KW  = ["/case-stud", "/case_stud", "/portfolio", "/use-case", "/use_case", 
                "/references", "casestudy", "case-study"]
STORY_URL_KW = ["/success-stor", "/success_stor", "/client-stor", "/client_stor", 
                "/customers", "success-story", "successstory", "customer-story",
                "customer-stories"]
BLOG_TEXT_KW = ["blog", "article", "insight", "news", "post", "update", "press"]
CASE_TEXT_KW = ["case study", "case studies", "case-study", "portfolio", "use case", "references"]
STORY_TEXT_KW = ["success story", "success stories", "client story", "client stories", 
                 "customer story", "customer stories", "successstory", "testimonial"]
# Nav items whose text/href suggests a container menu (Resources, More, Solutions…)
CONTAINER_KW = ["resource", "resources", "more", "solutions", "learn",
                "library", "knowledge", "media", "content", "company", "stories"]

DATE_REGEX = re.compile(
    r"^(january|february|march|april|may|june|july|august|september|"
    r"october|november|december)\s+\d{1,2},?\s+\d{4}$", re.I
)
GENERIC_LINK_TEXT = {"read more", "view more", "learn more",
                     "click here", "→", "»", "see more", "explore",
                     "continue reading"}
BAD_URL_PATTERNS = [
    "workdrive", "store.zoho", "drive.google", "dropbox",
    "filedownload", ".pdf", ".doc", ".ppt", ".xls",
    "/contact", "/about", "/pricing", "/login", "/signup", "/signin",
    "/tag/", "/category/", "/author/", "/page/", "/feed", "/rss",
    "/privacy", "/terms", "/cookie", "/legal", "/security",
    "javascript:", "mailto:", "tel:",
]


def _categorise_by_url(url: str) -> str | None:
    """Return 'blogs', 'case_studies' or 'customer_stories' based on URL patterns."""
    lower = url.lower()
    if any(k in lower for k in STORY_URL_KW): return 'customer_stories'
    if any(k in lower for k in CASE_URL_KW): return 'case_studies'
    if any(k in lower for k in BLOG_URL_KW): return 'blogs'
    return None


def _categorise_by_text(text: str) -> str | None:
    """Return 'blogs', 'case_studies' or 'customer_stories' based on link text."""
    lower = text.lower()
    if any(k in lower for k in STORY_TEXT_KW): return 'customer_stories'
    if any(k in lower for k in CASE_TEXT_KW): return 'case_studies'
    if any(k in lower for k in BLOG_TEXT_KW): return 'blogs'
    return None


def _expand_nav_fully(page) -> None:
    """
    Click / hover every nav-level toggle, dropdown trigger, and 'More' button
    so that hidden sub-menus are rendered in the DOM before we scrape links.

    Strategy:
      1. Hover all nav <li> and <button> elements (reveals CSS :hover menus).
      2. Click elements whose text is a known container keyword (Resources, More…).
      3. Wait for any JS animations to settle.
      4. Repeat once more for deeply nested menus (e.g. mega-menus).
    """
    js = """
        async () => {
            const NAV_SELECTORS = [
                'nav', 'header', '.navbar', '.nav', '.menu',
                '.navigation', '[role="navigation"]',
                '.header-nav', '.site-nav', '.main-nav',
                '#navbar', '#header-menu', '#main-menu',
            ];
            const CONTAINER_KW = [
                'resource', 'resources', 'more', 'solutions', 'learn',
                'library', 'knowledge', 'media', 'content', 'company',
                'services', 'products', 'platform', 'tools',
            ];

            function dispatchHover(el) {
                ['mouseover', 'mouseenter', 'focus'].forEach(evt =>
                    el.dispatchEvent(new MouseEvent(evt, { bubbles: true }))
                );
            }

            // Collect all candidate nav elements
            const seen = new Set();
            const candidates = [];
            NAV_SELECTORS.forEach(sel => {
                document.querySelectorAll(
                    sel + ' li, ' + sel + ' button, ' +
                    sel + ' [class*="dropdown"], ' +
                    sel + ' [class*="toggle"], ' +
                    sel + ' [class*="menu-item"], ' +
                    sel + ' [class*="nav-item"], ' +
                    sel + ' [class*="more"]'
                ).forEach(el => {
                    if (!seen.has(el)) { seen.add(el); candidates.push(el); }
                });
            });

            // Pass 1: hover everything to reveal CSS-driven dropdowns
            candidates.forEach(dispatchHover);
            await new Promise(r => setTimeout(r, 600));

            // Pass 2: click container-keyword elements to open JS-driven menus
            candidates.forEach(el => {
                const t = (el.innerText || el.textContent || '').trim().toLowerCase();
                const isContainer = CONTAINER_KW.some(kw => t === kw || t.startsWith(kw));
                const hasArrow = el.querySelector(
                    'svg, .arrow, .caret, .chevron, [class*="arrow"], [class*="caret"]'
                );
                const hasToggle = el.getAttribute('aria-haspopup') ||
                                  el.getAttribute('aria-expanded') !== null ||
                                  el.getAttribute('data-toggle');
                if (isContainer || hasArrow || hasToggle) {
                    dispatchHover(el);
                    try { el.click(); } catch(e) {}
                }
            });
            await new Promise(r => setTimeout(r, 800));

            // Pass 3: hover/click newly visible elements (for nested mega-menus)
            const newCandidates = [];
            candidates.forEach(el => {
                el.querySelectorAll('li, button, a').forEach(child => {
                    if (!seen.has(child)) { seen.add(child); newCandidates.push(child); }
                });
            });
            newCandidates.forEach(dispatchHover);
            await new Promise(r => setTimeout(r, 500));
        }
    """
    try:
        page.evaluate(js)
        page.wait_for_timeout(2000)
    except Exception as e:
        print(f"[*] Warning: nav expansion error: {e}", file=sys.stderr)


def _collect_all_nav_links(page, base_domain: str) -> list[dict]:
    """
    Collect every visible link from nav / header / footer after menus are expanded.
    Returns list of {text, href}.
    """
    return page.evaluate("""
        (baseDomain) => {
            const SELECTORS = [
                'nav a', 'header a', '.navbar a', '.nav a', '.menu a',
                '.navigation a', '[role="navigation"] a',
                '.header-nav a', '.site-nav a', '.main-nav a',
                '#navbar a', '#header-menu a', '#main-menu a',
                '.wd-nav-main a', '.woodmart-nav-link a', '.wd-main-menu a',
                // also catch any newly-revealed dropdown panels
                '[class*="dropdown"] a', '[class*="submenu"] a',
                '[class*="mega-menu"] a', '[class*="flyout"] a',
                '[aria-expanded] + * a', '[data-toggle] + * a',
                'footer a', '.footer a',
            ];
            const links = [];
            const seen = new Set();
            SELECTORS.forEach(sel => {
                document.querySelectorAll(sel).forEach(a => {
                    const href = a.href || '';
                    // Use textContent so hidden-then-revealed links are included
                    const text = (a.textContent || a.innerText || '').trim();
                    if (!href || seen.has(href)) return;
                    if (!href.includes(baseDomain)) return;
                    if (href.includes('#') || href.includes('javascript')) return;
                    seen.add(href);
                    links.push({ text: text.toLowerCase(), href });
                });
            });
            return links;
        }
    """, base_domain)


def _build_listing_targets(nav_links: list[dict], site_url: str) -> list[dict]:
    """
    From nav links decide which pages are listing pages for blogs / case studies.
    Returns list of {url, type} where type ∈ {'blogs', 'case_studies', 'generic'}.

    Logic (priority order):
      1. URL pattern  → direct match to BLOG_URL_KW / CASE_URL_KW
      2. Link text    → match to BLOG_TEXT_KW / CASE_TEXT_KW
      3. Container kw → link text is a known resource hub (Resources, Library…) → generic
         BUT only if the URL itself also looks like a hub (not a specific service page)
    """
    # URL segments that indicate a specific service/product page — never list pages
    SERVICE_URL_KW = [
        '/services', '/service/', '/implementation', '/accounting', '/consulting',
        '/development', '/marketing', '/solutions', '/products', '/platform',
        '/about', '/contact', '/pricing', '/career', '/job', '/jobs',
        '/privacy', '/terms', '/login', '/signup',
        '/erp', '/ecommerce', '/e-commerce', '/crm', '/hrm', '/automation',
        '/support', '/integrat', '/custom-business', '/website-development',
        '/brand-growth', '/zoho-one', '/zoho-crm', '/zoho-books',
    ]

    def is_service_url(url: str) -> bool:
        lower = url.lower()
        return any(kw in lower for kw in SERVICE_URL_KW)

    targets = []
    seen_urls = set()

    for item in nav_links:
        href = item["href"]
        text = item["text"]
        norm = href.rstrip("/")
        if norm in seen_urls:
            continue

        # Skip service/utility pages immediately — they are never listing pages
        if is_service_url(href):
            continue

        cat = _categorise_by_url(href) or _categorise_by_text(text)

        if cat is None:
            # Only mark as generic if the link TEXT looks like a resource hub
            # AND the URL itself is a short/hub-style path (not a deep service page)
            is_hub_text = any(k in text for k in CONTAINER_KW)
            url_depth = len([p for p in href.rstrip('/').split('/') if p]) 
            is_short_path = url_depth <= 4  # e.g. trigya.co/resources is depth 1
            if is_hub_text and is_short_path:
                cat = "generic"
            else:
                continue  # Not relevant

        seen_urls.add(norm)
        targets.append({"url": href, "type": cat})
        print(f"[*]   [{cat}] nav target: {href!r}  (text={text!r})", file=sys.stderr)

    # Fallback: try well-known paths if nothing found
    if not targets:
        print("[*] No nav targets found, trying common paths.", file=sys.stderr)
        for path, ltype in [
            ("/blog", "blogs"), ("/blog/", "blogs"), ("/blogs", "blogs"), ("/articles", "blogs"),
            ("/insights", "blogs"), ("/news", "blogs"),
            ("/case-studies", "case_studies"), ("/case-studies/", "case_studies"),
            ("/success-stories", "case_studies"), ("/customers", "case_studies"),
            ("/portfolio", "case_studies"), ("/resources", "generic"),
        ]:
            targets.append({"url": urljoin(site_url, path), "type": ltype})

    # Prioritize specific categories over 'generic'
    targets.sort(key=lambda x: 0 if x["type"] in ["blogs", "case_studies", "customer_stories"] else 1)

    return targets


def _collect_articles_from_listing(agent, listing_url: str,
                                   base_domain: str, page_default_cat: str | None,
                                   strict_path_filter: bool = False) -> list[dict]:
    """
    Open a listing page, trigger any lazy-load / hover reveals,
    then harvest all article links with best-effort title and category.
    Returns list of {title, link, detectedCategory}.
    """
    try:
        resp = agent._safe_goto(listing_url, timeout=60000)
        if resp and resp.status >= 400:
            print(f"[*]   HTTP {resp.status} for {listing_url}, skipping.", file=sys.stderr)
            return []
        agent.page.wait_for_timeout(2500)
        agent._scroll_to_bottom()

        # Trigger hover reveals on card elements
        agent.page.evaluate("""
            () => {
                document.querySelectorAll(
                    'div, li, article, section, a, .card, [class*="post"], [class*="item"]'
                ).forEach(el => {
                    el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                    el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                });
            }
        """)
        agent.page.wait_for_timeout(800)

        # Scroll again in case new cards loaded
        agent._scroll_to_bottom()
        agent.page.wait_for_timeout(600)

    except Exception as e:
        print(f"[*]   Could not load listing {listing_url}: {e}", file=sys.stderr)
        return []

    return agent.page.evaluate(r"""
        (args) => {
            const { baseDomain, listingUrl, pageDefaultCat, strictPathFilter,
                    BLOG_URL_KW, CASE_URL_KW, STORY_URL_KW,
                    BLOG_TEXT_KW, CASE_TEXT_KW, STORY_TEXT_KW,
                    BAD_URL_PATTERNS, GENERIC_LINK_TEXT, DATE_REGEX_SRC } = args;

            const DATE_RE = new RegExp(DATE_REGEX_SRC, 'i');
            const GENERIC_SET = new Set(GENERIC_LINK_TEXT);

            function catByUrl(url) {
                const l = url.toLowerCase();
                if (STORY_URL_KW.some(k => l.includes(k))) return 'customer_stories';
                if (CASE_URL_KW.some(k => l.includes(k))) return 'case_studies';
                if (BLOG_URL_KW.some(k => l.includes(k))) return 'blogs';
                return null;
            }
            function catByText(text) {
                const l = text.toLowerCase();
                if (STORY_TEXT_KW.some(k => l.includes(k))) return 'customer_stories';
                if (CASE_TEXT_KW.some(k => l.includes(k))) return 'case_studies';
                if (BLOG_TEXT_KW.some(k => l.includes(k))) return 'blogs';
                return null;
            }

            // ── Shared helpers ───────────────────────────────────────────────
            const mainContent = document.body;
            const results = [];
            const seen = new Set();
            const normListing = listingUrl.replace(/\/$/, '');

            // URLs that are definitely NOT articles (service pages, nav, etc.)
            const BAD_PATH_PATTERNS = [
                '/services', '/service/', '/about', '/contact', '/pricing',
                '/login', '/signup', '/signin', '/job', '/career', '/jobs',
                '/tag/', '/category/', '/author/', '/page/', '/feed',
                '/privacy', '/terms', '/cookie', '/legal',
                '/implementation', '/accounting', '/consulting', '/development',
                '/marketing', '/solutions', '/products', '/platform',
                'javascript:', 'mailto:', 'tel:',
            ];
            function isBadUrl(url) {
                const l = url.toLowerCase();
                return BAD_PATH_PATTERNS.some(p => l.includes(p));
            }
            function addResult(href, title, cat) {
                if (!href || !href.startsWith('http') || !href.includes(baseDomain)) return;
                if (isBadUrl(href)) return;
                const norm = href.replace(/\/$/, '');
                if (norm === normListing || seen.has(norm)) return;
                seen.add(norm);
                const finalTitle = (title || '').split('\n')[0].trim();
                if (finalTitle.length < 5) return;
                // catByUrl gives the most reliable signal; then the listing page's own category;
                // final fallback: 'case_studies' is safer than 'blogs' for slug-only URLs
                const resolvedCat = catByUrl(href) || pageDefaultCat || 'case_studies';
                results.push({
                    title: finalTitle,
                    link: href,
                    detectedCategory: resolvedCat
                });
            }

            // ── PASS 1: WordPress / flat-heading pattern ─────────────────────
            // Handles blog pages like trigya.co/blog where each post is:
            //   <h3><a href="/slug/">Post Title</a></h3>  (title link IS inside heading)
            mainContent.querySelectorAll('h2 > a[href], h3 > a[href], h4 > a[href]').forEach(titleAnchor => {
                if (titleAnchor.closest('nav, header, footer, .menu, [role="navigation"]')) return;
                const href = titleAnchor.href || '';
                const title = (titleAnchor.innerText || titleAnchor.textContent || '').trim();
                if (title.length > 10) addResult(href, title, null);
            });

            // ── PASS 1b: Heading + nearby CTA pattern ────────────────────────
            // Handles pages like trigya.co/case-studies/ where each card is:
            //   <h3>Robert Griffin</h3>  ← plain text heading, NO <a> inside
            //   <a href="/robert-griffin/">Read More</a>  ← CTA link nearby
            // Strategy: find every standalone h3/h4 (not wrapping an <a>), then
            // look for the nearest "Read More" link within the same tight container.
            if (results.length === 0) {
                mainContent.querySelectorAll('h3, h4').forEach(heading => {
                    // h2 is too likely to be a page/section title — only h3/h4 are card titles
                    if (heading.closest('nav, header, footer, .menu, [role="navigation"]')) return;
                    // Skip headings that already contain an <a> (handled by Pass 1)
                    if (heading.querySelector('a')) return;

                    const title = (heading.innerText || heading.textContent || '').trim();
                    if (title.length < 3 || title.length > 150) return;

                    // Only search the IMMEDIATE parent container — not body/grandparent.
                    // This prevents a section h2 from stealing a Read More link from a
                    // card that is several siblings away.
                    let ctaLink = null;
                    const parent = heading.parentElement;
                    if (!parent) return;

                    // Reject if the parent is too large (body, main, section with many children)
                    // or is a structural element — card containers are always divs/li/figure etc.
                    const parentTag = parent.tagName.toLowerCase();
                    if (parentTag === 'body' || parentTag === 'main' || parentTag === 'html') return;
                    const directChildCount = parent.children.length;
                    if (directChildCount > 10) return;

                    const anchors = parent.querySelectorAll('a[href]');
                    for (const a of anchors) {
                        const txt = (a.innerText || a.textContent || '').trim().toLowerCase();
                        if (txt.includes('read more') || txt.includes('continue reading') ||
                            txt.includes('learn more') || txt.includes('view more')) {
                            ctaLink = a;
                            break;
                        }
                    }

                    if (ctaLink) addResult(ctaLink.href, title, null);
                });
            }

            // ── PASS 2: Card container scraper ───────────────────────────────
            // Handles sites that wrap each post in article / .card / .post-* etc.
            if (results.length === 0) {
                const cards = mainContent.querySelectorAll(
                    'article, .card, [class*="post-item" i], [class*="blog-item" i], ' +
                    '[class*="post-card" i], [class*="blog-card" i], ' +
                    '[class*="wd-" i], .woodmart-info-box'
                );
                cards.forEach(card => {
                    if (card.closest('nav, header, footer')) return;
                    const links = card.querySelectorAll('a[href]');
                    let bestLink = null;
                    let bestTitle = '';

                    // Prefer "Read More / Continue reading" CTA — its href IS the article URL
                    for (const a of links) {
                        const txt = (a.innerText || a.textContent || '').trim().toLowerCase();
                        if (txt.includes('read more') || txt.includes('continue reading') || txt.includes('learn more')) {
                            bestLink = a;
                            break;
                        }
                    }
                    // Otherwise use first link with a real title
                    if (!bestLink) {
                        for (const a of links) {
                            const txt = (a.innerText || a.textContent || '').trim();
                            if (txt.length > 10 && !DATE_RE.test(txt) && !GENERIC_SET.has(txt.toLowerCase())) {
                                bestLink = a;
                                bestTitle = txt;
                                break;
                            }
                        }
                    }
                    if (!bestLink) return;

                    // Pull title from the card heading if we don't have one yet
                    if (!bestTitle) {
                        const heading = card.querySelector('h1,h2,h3,h4,h5,h6,[class*="title" i]');
                        bestTitle = heading ? (heading.innerText || heading.textContent || '').trim() : '';
                    }
                    if (!bestTitle) {
                        bestTitle = (bestLink.innerText || bestLink.textContent || '').trim();
                    }

                    addResult(bestLink.href, bestTitle, null);
                });
            }

            // ── PASS 3: Strict fallback — only accept links that look like articles ──
            // Triggered only when passes 1 & 2 both find nothing.
            // Unlike the old fallback, this one enforces that the URL must:
            //   a) match a known content keyword, OR
            //   b) be a slug-style URL (no known service/page patterns) with a
            //      heading sibling or long anchor text.
            if (results.length === 0) {
                mainContent.querySelectorAll('a[href]').forEach(a => {
                    if (a.closest('nav, header, footer, .menu, [role="navigation"]')) return;
                    const href = a.href || '';
                    if (!href.startsWith('http') || !href.includes(baseDomain)) return;
                    if (isBadUrl(href)) return;
                    const norm = href.replace(/\/$/, '');
                    if (norm === normListing || seen.has(norm)) return;

                    const txt = (a.innerText || a.textContent || '').trim();
                    const lowerTxt = txt.toLowerCase();

                    // Must have real text AND either a known content URL pattern
                    // or a heading nearby (indicates it's a genuine article link)
                    const hasContentUrl = catByUrl(href) !== null;
                    const nearHeading = !!a.closest('h1,h2,h3,h4,h5,h6') ||
                                        !!a.querySelector('h1,h2,h3,h4,h5,h6');
                    const isCtaLink = GENERIC_SET.has(lowerTxt);  // "continue reading" etc.

                    if (txt.length > 15 && (hasContentUrl || nearHeading || isCtaLink)) {
                        // For CTA links without titles, look for sibling heading
                        let title = isCtaLink ? '' : txt;
                        if (!title) {
                            const parent = a.parentElement;
                            const sib = parent && parent.querySelector('h1,h2,h3,h4,h5,h6');
                            title = sib ? (sib.innerText || sib.textContent || '').trim() : txt;
                        }
                        seen.add(norm);
                        results.push({
                            title: (title || txt).split('\n')[0].trim(),
                            link: href,
                            detectedCategory: catByUrl(href) || pageDefaultCat || 'case_studies'
                        });
                    }
                });
            }

            return results;
        }
    """, {
        "baseDomain": base_domain,
        "listingUrl": listing_url,
        "pageDefaultCat": page_default_cat,
        "strictPathFilter": strict_path_filter,
        "BLOG_URL_KW": BLOG_URL_KW,
        "CASE_URL_KW": CASE_URL_KW,
        "STORY_URL_KW": STORY_URL_KW,
        "BLOG_TEXT_KW": BLOG_TEXT_KW,
        "CASE_TEXT_KW": CASE_TEXT_KW,
        "STORY_TEXT_KW": STORY_TEXT_KW,
        "BAD_URL_PATTERNS": BAD_URL_PATTERNS,
        "GENERIC_LINK_TEXT": list(GENERIC_LINK_TEXT),
        "DATE_REGEX_SRC": DATE_REGEX.pattern,
    })


def _page_default_category(page) -> str | None:
    """
    Infer the category of a listing page from its h1 / page-title element,
    then from the URL. URL-based fallback is critical for sites like trigya.co
    where the heading text ('Real Results, Proven Success') contains no keyword.
    """
    try:
        heading = page.evaluate("""
            () => {
                const el = document.querySelector(
                    'h1, .page-title, .hero-title, .section-heading, .page-heading'
                );
                return el ? (el.innerText || el.textContent || '').trim() : '';
            }
        """)
        if heading:
            cat = _categorise_by_text(heading)
            if cat:
                return cat
    except Exception:
        pass
    # Always fall back to URL-based detection (reliable for /blog/, /case-studies/, etc.)
    return _categorise_by_url(page.url)


def extract_from_external_website(agent, url: str) -> dict:
    """
    3-Step extraction from a company's official website:

    Step 1 — Fully expand navbar (CSS hover + JS click on dropdowns/More menus)
              then collect ALL nav/header/footer links.
    Step 2 — For every relevant listing page: open it, reveal lazy-loaded cards,
              harvest article links with title + category.
    Step 3 — Navigate to each article and extract its full text content.
    """
    results = {"blogs": [], "case_studies": [], "customer_stories": []}
    MAX_ARTICLES_PER_CAT = 5
    MAX_LISTING_PAGES = 8   # up from 4 — more nav targets explored

    try:
        # ── Step 1: Load homepage, expand nav, collect links ─────────────────
        print(f"[*] Step 1: Loading site and expanding nav: {url}", file=sys.stderr)
        agent.page.goto(url, wait_until="domcontentloaded", timeout=30000)
        agent.page.wait_for_timeout(2500)

        parsed = urlparse(url)
        base_domain = parsed.netloc.replace("www.", "")

        _expand_nav_fully(agent.page)

        nav_links = _collect_all_nav_links(agent.page, base_domain)
        print(f"[*]   Collected {len(nav_links)} nav links total.", file=sys.stderr)

        listing_targets = _build_listing_targets(nav_links, url)
        print(f"[*]   {len(listing_targets)} listing targets identified.", file=sys.stderr)

        # ── Step 2: Visit each listing page, collect article links ────────────
        article_queue: dict[str, list] = {"blogs": [], "case_studies": [], "customer_stories": []}
        # Track seen links PER CATEGORY so a blog URL found as a cross-link on
        # the case-studies page doesn't block it from being queued from the blog listing
        seen_links: dict[str, set] = {"blogs": set(), "case_studies": set(), "customer_stories": set()}

        for target in listing_targets[:MAX_LISTING_PAGES]:
            print(f"[*] Step 2: Scanning listing page [{target['type']}]: {target['url']}",
                  file=sys.stderr)

            # Use the target's own type as the default category for articles found on it.
            # This is the most reliable signal — a page identified as 'blogs' listing
            # will contain blog articles, even if their URLs are slug-only (no /blog/ prefix).
            # For 'generic' targets we still try to infer from the page heading/URL.
            if target["type"] != "generic":
                page_default_cat = target["type"]
            else:
                page_default_cat = _page_default_category(agent.page) \
                    if target["url"] == url else None

            articles = _collect_articles_from_listing(
                agent, target["url"], base_domain, page_default_cat
            )

            # For generic targets: re-read category from the loaded page
            if target["type"] == "generic" and not page_default_cat:
                page_default_cat = _page_default_category(agent.page)

            # Re-apply page default to articles that have no category yet
            for art in articles:
                if not art.get("detectedCategory") and page_default_cat:
                    art["detectedCategory"] = page_default_cat

            print(f"[*]   Found {len(articles)} candidate article links.", file=sys.stderr)

            for art in articles:
                lk = art["link"].rstrip("/")

                # Determine final bucket first, then check per-category dedup
                detected = art.get("detectedCategory")
                if detected in article_queue:
                    cat = detected
                elif target["type"] != "generic" and target["type"] in article_queue:
                    cat = target["type"]
                else:
                    cat = "case_studies"

                # Deduplicate within the bucket only — not globally across categories
                if lk in seen_links[cat]:
                    continue
                seen_links[cat].add(lk)

                if len(article_queue[cat]) < MAX_ARTICLES_PER_CAT:
                    article_queue[cat].append(art)
                    print(f"[*]     → queued [{cat}]: {art['link']}", file=sys.stderr)

            # Early exit only when all buckets have ENOUGH articles
            if all(len(v) >= MAX_ARTICLES_PER_CAT for v in article_queue.values()):
                print("[*]   All buckets full, stopping listing scan.", file=sys.stderr)
                break

        # ── Step 3: Extract full content from each article ────────────────────
        for cat, arts in article_queue.items():
            for art in arts:
                print(f"[*] Step 3: Extracting [{cat}]: {art['link']}", file=sys.stderr)
                content = extract_page_content(agent, art["link"])
                results[cat].append({
                    "title": art["title"],
                    "link": art["link"],
                    "content": content or "Content extraction failed.",
                    "detected_type": cat
                })

    except Exception as e:
        print(f"[*] External site error: {e}", file=sys.stderr)

    return results

def extract_from_manual_links(agent, blog_url: str | None, case_study_url: str | None, customer_story_url: str | None = None) -> dict:
    """
    Scrapes blogs, case studies, and customer stories from specific URLs.
    """
    results = {"blogs": [], "case_studies": [], "customer_stories": []}
    MAX_ARTICLES_PER_CAT = 5
    
    listing_targets = []
    if blog_url:
        listing_targets.append({"url": blog_url, "type": "blogs"})
    if case_study_url:
        listing_targets.append({"url": case_study_url, "type": "case_studies"})
    if customer_story_url:
        listing_targets.append({"url": customer_story_url, "type": "customer_stories"})
        
    if not listing_targets:
        return results

    try:
        # Get base_domain for filtering
        first_url = blog_url or case_study_url
        parsed = urlparse(first_url)
        base_domain = parsed.netloc.replace("www.", "")

        article_queue: dict[str, list] = {"blogs": [], "case_studies": [], "customer_stories": []}
        seen_links: set[str] = set()

        for target in listing_targets:
            print(f"[*] Scanning provided listing page [{target['type']}]: {target['url']}", file=sys.stderr)
            
            # Use strict_path_filter=False for manual links because we trust the user's provided URL
            articles = _collect_articles_from_listing(
                agent, target["url"], base_domain, target["type"], strict_path_filter=False
            )

            print(f"[*]   Found {len(articles)} candidate article links.", file=sys.stderr)

            for art in articles:
                lk = art["link"].rstrip("/")
                if lk in seen_links:
                    continue
                seen_links.add(lk)

                # Use the detected category if available, else fallback to the target type
                cat = art.get("detectedCategory") or target["type"]
                if cat not in article_queue: 
                    cat = "case_studies" # safe fallback

                if len(article_queue[cat]) < MAX_ARTICLES_PER_CAT:
                    article_queue[cat].append(art)
                    print(f"[*]     → queued [{cat}]: {art['link']}", file=sys.stderr)

        # Step 3: Extract content from each article
        for cat, arts in article_queue.items():
            for art in arts:
                print(f"[*] Extracting [{cat}]: {art['link']}", file=sys.stderr)
                content = extract_page_content(agent, art["link"])
                results[cat].append({
                    "title": art["title"],
                    "link": art["link"],
                    "content": content or "Content extraction failed.",
                    "detected_type": cat
                })

    except Exception as e:
        print(f"[*] Manual links extraction error: {e}", file=sys.stderr)

    return results


def extract_social_links(agent) -> dict:
    """Find Instagram, Twitter, Facebook, and YouTube links on the partner's website."""
    social_links = {"instagram": None, "twitter": None, "facebook": None, "youtube": None}
    platforms = {
        "instagram": ["instagram.com"],
        "twitter": ["twitter.com", "x.com"],
        "facebook": ["facebook.com"],
        "youtube": ["youtube.com"]
    }
    
    try:
        # 1. Scroll to ensure footer/sidebars are rendered
        agent._scroll_to_bottom()
        agent.page.wait_for_timeout(1000)
        
        # 2. General anchor search
        anchors = agent.page.locator("a[href]").all()
        for a in anchors:
            try:
                href = a.get_attribute("href")
                if not href: continue
                for platform, keywords in platforms.items():
                    if social_links.get(platform): continue
                    if any(kw in href.lower() for kw in keywords):
                        # Filter out generic/corporate links and sharing intents
                        if not any(x in href.lower() for x in ["share", "intent", "sharer", "plugins", "zoho", "/p/"]):
                            social_links[platform] = href
            except Exception: continue
            
        # 3. Icon-based fallback (if text is missing)
        if not all(social_links.values()):
            icon_selectors = {
                "instagram": ["i.fa-instagram", ".instagram", "[class*='instagram' i]"],
                "twitter": ["i.fa-twitter", "i.fa-x-twitter", ".twitter", "[class*='twitter' i]", "[class*='x-twitter' i]"],
                "facebook": ["i.fa-facebook", ".facebook", "[class*='facebook' i]"],
                "youtube": ["i.fa-youtube", ".youtube", "[class*='youtube' i]"]
            }
            for platform, selectors in icon_selectors.items():
                if social_links.get(platform): continue
                for sel in selectors:
                    try:
                        icon = agent.page.locator(sel).first
                        if icon.count() > 0:
                            # Try to find parent anchor
                            parent = icon.locator("xpath=ancestor::a").first
                            if parent.count() > 0:
                                href = parent.get_attribute("href")
                                if href and any(kw in href.lower() for kw in platforms[platform]):
                                    social_links[platform] = agent._absolute_url(href)
                                    break
                    except Exception: continue
                    
    except Exception as e:
        print(f"[*] Warning: Error extracting social links: {e}", file=sys.stderr)
        
    return social_links


def scrape_social_platform(agent, url: str, platform: str) -> dict:
    """Best-effort scrape of a social media profile without login."""
    print(f"[*] Attempting best-effort scrape of {platform}: {url}", file=sys.stderr)
    data = {"url": url, "bio": None, "posts": [], "error": None}
    
    try:
        agent.page.goto(url, wait_until="domcontentloaded", timeout=30000)
        agent.page.wait_for_timeout(4000)
        
        if platform == "instagram":
            # Bio extraction
            bio = agent.page.locator("meta[name='description']").get_attribute("content")
            if not bio:
                bio = agent._safe_text("header section")
            data["bio"] = bio
            
            # Captions from images
            anchors = agent.page.locator("a[href*='/p/'] img").all()
            for img in anchors[:5]:
                alt = img.get_attribute("alt")
                if alt:
                    data["posts"].append({"content": alt})
                
        elif platform == "twitter":
            data["bio"] = agent._safe_text("[data-testid='UserDescription']") or agent.page.title()
            tweets = agent.page.locator("[data-testid='tweetText']").all()
            for t in tweets[:3]:
                data["posts"].append({"content": t.inner_text()})
                
        elif platform == "facebook":
            data["bio"] = agent._safe_text("div:has-text('About') + div") or agent.page.title()
            posts = agent.page.locator("[data-ad-preview='message']").all()
            for p in posts[:3]:
                data["posts"].append({"content": p.inner_text()})
        elif platform == "youtube":
            data["bio"] = agent._safe_text("#description-container") or agent.page.title()
            videos = agent.page.locator("#video-title").all()
            for v in videos[:3]:
                data["posts"].append({"content": v.inner_text()})
                
    except Exception as e:
        data["error"] = str(e)
        print(f"[*] Social scrape warning for {platform}: {e}", file=sys.stderr)
        
    return data