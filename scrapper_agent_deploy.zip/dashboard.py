import os
import sys
import subprocess
import glob
import json
import time
import re
from flask import Flask, render_template_string, send_from_directory, jsonify, request
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Paths - Using absolute paths to ensure data visibility
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_DIR = os.path.join(BASE_DIR, "trigya report")
COLLECTIONS_DIR = os.path.join(BASE_DIR, "partner_collections")
OUTPUT_DIR = os.path.join(BASE_DIR, "scraped_data")

# Global task tracker
active_tasks = {
    "report": None,
    "scrape": None,
    "sync": None
}

# Persistent system state
system_state = {
    "status": "OPERATIONAL",
    "color": "#4ade80",
    "bg": "rgba(34, 197, 94, 0.1)"
}

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trigya Intelligence Hub | Strategic Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        :root {
            --bg-deep: #010409;
            --bg-card: rgba(13, 17, 23, 0.7);
            --accent-orange: #f97316;
            --accent-blue: #38bdf8;
            --text-primary: #f0f6fc;
            --text-secondary: #8b949e;
            --border: rgba(48, 54, 61, 0.5);
            --glass-blur: blur(20px);
            --navy-dark: #0d1117;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-deep);
            background-image: 
                radial-gradient(circle at 0% 0%, rgba(249, 115, 22, 0.1) 0%, transparent 40%),
                radial-gradient(circle at 100% 100%, rgba(56, 189, 248, 0.1) 0%, transparent 40%);
            color: var(--text-primary);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Sidebar Glassmorphism */
        .sidebar {
            width: 300px;
            background: rgba(13, 17, 23, 0.8);
            backdrop-filter: var(--glass-blur);
            border-right: 1px solid var(--border);
            padding: 40px 24px;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
        }

        .logo-container {
            margin-bottom: 48px;
            padding: 12px;
            background: white;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 30px rgba(0,0,0,0.5);
        }
        .logo-img { width: 100%; border-radius: 8px; }

        .main-workspace {
            margin-left: 300px;
            flex: 1;
            padding: 48px;
            max-width: 1400px;
            width: calc(100% - 300px);
        }

        /* Nav & Sections */
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.2); }
        }
        .animate-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }

        .nav-section { margin-bottom: 32px; }
        .nav-label {
            font-family: 'Outfit', sans-serif;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--accent-blue);
            margin-bottom: 16px;
            display: block;
            text-shadow: 0 0 10px rgba(56, 189, 248, 0.3);
            opacity: 0.9;
        }

        /* Buttons & Inputs */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 16px 24px;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid transparent;
            width: 100%;
            white-space: nowrap;
            letter-spacing: -0.2px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
            color: white;
            box-shadow: 0 8px 20px -4px rgba(234, 88, 12, 0.4);
            position: relative;
            overflow: hidden;
        }
        .btn-primary::after {
            content: '';
            position: absolute;
            top: -50%; left: -50%; width: 200%; height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            transform: rotate(45deg);
            transition: 0.5s;
            opacity: 0;
        }
        .btn-primary:hover::after { left: 100%; opacity: 1; }
        .btn-primary:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 12px 25px -5px rgba(234, 88, 12, 0.6);
        }
        .btn-primary:active { transform: translateY(-1px); }

        .status-btn { 
            background: rgba(255,255,255,0.03); 
            border: 1px solid rgba(255,255,255,0.05);
            transition: all 0.3s ease;
            color: rgba(255,255,255,0.6);
        }
        .status-btn:hover { background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.2); color: white; }
        .status-btn.active { background: rgba(249, 115, 22, 0.15); border-color: var(--accent-orange); color: white; }

        .btn-ghost {
            background: rgba(30, 41, 59, 0.3);
            backdrop-filter: blur(8px);
            border: 1px solid var(--border);
            color: var(--text-primary);
        }
        .btn-ghost:hover {
            background: rgba(30, 41, 59, 0.6);
            border-color: var(--accent-blue);
            color: var(--accent-blue);
        }

        /* Cards */
        .glass-card {
            background: linear-gradient(135deg, rgba(13, 17, 23, 0.8) 0%, rgba(13, 17, 23, 0.5) 100%);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 32px;
            margin-bottom: 32px;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }
        .glass-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 1px;
            background: linear-gradient(90deg, transparent, var(--border), transparent);
        }
        .glass-card:hover { 
            border-color: var(--accent-orange);
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.6), 0 0 20px rgba(249, 115, 22, 0.1);
        }

        .card-header { margin-bottom: 28px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 16px; }
        .card-title {
            font-family: 'Outfit', sans-serif;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #fff;
            text-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }
        .card-subtitle { font-size: 14px; color: var(--text-secondary); line-height: 1.6; }

        /* Search Bar */
        .search-area {
            position: relative;
            display: flex;
            gap: 12px;
        }
        .input-glow {
            flex: 1;
            background: #0d1117;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 14px 18px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
            appearance: none;
        }
        .input-glow option {
            background-color: #0d1117;
            color: white;
            padding: 12px;
        }
        .input-glow:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.1);
            background: rgba(2, 6, 23, 0.8);
        }
        .input-compact {
            padding: 10px 14px;
            font-size: 13px;
            border-radius: 10px;
        }

        /* Advanced Options */
        .advanced-trigger {
            margin-top: 16px;
            color: var(--text-secondary);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            user-select: none;
        }
        .advanced-trigger:hover { color: var(--accent-blue); }

        .advanced-panel {
            display: none;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
        }

        /* History & Lists */
        .grid-dashboard {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 32px;
        }

        .list-container { 
            display: flex; 
            flex-direction: column; 
            gap: 12px; 
            max-height: 400px; 
            overflow-y: auto; 
            padding-right: 8px;
        }
        .list-container::-webkit-scrollbar { width: 5px; }
        .list-container::-webkit-scrollbar-track { background: rgba(255,255,255,0.02); }
        .list-container::-webkit-scrollbar-thumb { background: var(--accent-blue); border-radius: 10px; }

        .list-item {
            background: rgba(30, 41, 59, 0.3);
            border: 1px solid var(--border);
            padding: 16px 20px;
            border-radius: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.2s;
        }
        .list-item:hover {
            background: rgba(30, 41, 59, 0.6);
            border-color: var(--accent-orange);
            transform: translateX(4px);
        }
        .item-main { display: flex; flex-direction: column; gap: 4px; }
        .item-title { font-size: 16px; font-weight: 700; color: #fff; }
        .item-subtitle { font-size: 11px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600; }

        /* Status Pills */
        .status-pill {
            padding: 4px 10px;
            border-radius: 99px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            background: rgba(56, 189, 248, 0.1);
            color: var(--accent-blue);
            border: 1px solid rgba(56, 189, 248, 0.2);
        }

        .toggle-view-btn {
            margin-top: 16px;
            text-align: center;
            font-size: 13px;
            font-weight: 700;
            color: var(--accent-blue);
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.2s;
            display: none;
        }
        .toggle-view-btn:hover { color: var(--accent-orange); text-shadow: 0 0 8px rgba(249, 115, 22, 0.4); }

        /* Animation */
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-in { animation: fadeIn 0.5s ease-out forwards; }

        .progress-track {
            height: 6px;
            background: rgba(255,255,255,0.05);
            border-radius: 10px;
            overflow: hidden;
            margin-top: 16px;
            display: none;
        }
        .progress-fill {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, var(--accent-orange), #ea580c);
            transition: width 0.3s ease;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-deep); }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #334155; }
        
        .animate-spin { animation: spin 1.5s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        
        @keyframes pulseGlow {
            0% { box-shadow: 0 0 0 0 rgba(234, 88, 12, 0.5); border-color: rgba(234, 88, 12, 0.5); }
            70% { box-shadow: 0 0 0 12px rgba(234, 88, 12, 0); border-color: rgba(234, 88, 12, 0.2); }
            100% { box-shadow: 0 0 0 0 rgba(234, 88, 12, 0); border-color: rgba(234, 88, 12, 0.5); }
        }
        .animate-pulse-glow { animation: pulseGlow 2s infinite; }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo-container">
            <img src="/logo" alt="Trigya Logo" class="logo-img">
        </div>
        
        <div class="nav-section" style="margin-bottom: 28px;">
            <span class="nav-label" style="font-size: 10px; margin-bottom: 12px;">Core Operations</span>
            <select id="sync-select" class="input-glow input-compact partner-select" style="width: 100%; margin-bottom: 12px; background: rgba(15, 23, 42, 0.4);">
                <option value="">(Global Ecosystem Sync)</option>
            </select>
            <button class="btn btn-ghost" onclick="syncCollections()" id="sync-btn" style="padding: 10px 14px; font-size: 13px; border-radius: 10px;">
                <i data-lucide="refresh-cw" size="16"></i> Sync Target Data
            </button>
        </div>

        <div class="nav-section">
            <span class="nav-label" style="font-size: 10px; margin-bottom: 12px;">Strategic Mapping</span>
            <div class="glass-card" style="padding: 18px; border-radius: 16px; background: rgba(15, 23, 42, 0.6); box-shadow: inset 0 0 15px rgba(0,0,0,0.2);">
                <label class="nav-label" style="font-size: 9px; opacity: 0.6; margin-bottom: 8px; letter-spacing: 1px;">Analytical Baseline</label>
                <select id="baseline-select" class="input-glow input-compact partner-select" style="width: 100%; margin-bottom: 14px; background: rgba(2, 6, 23, 0.9);">
                    <option value="">(Default: First Partner)</option>
                </select>
                <button class="btn btn-primary animate-pulse-glow" onclick="runBulkReport()" id="bulk-btn" style="padding: 12px 18px; font-size: 13px;">
                    <i data-lucide="map" size="18"></i> Generate Market Map
                </button>
                <div class="progress-track" id="report-progress-container">
                    <div class="progress-fill" id="report-progress-bar"></div>
                </div>
                <div id="status-text" style="font-size: 11px; margin-top: 12px; color: var(--text-secondary);"></div>
            </div>
        </div>

        <div style="margin-top: auto; font-size: 11px; opacity: 0.5;">
            v1.2 Advanced Intelligence Agent
        </div>
    </aside>

    <main class="main-workspace">
        <header class="animate-in" style="margin-bottom: 48px; display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
                <h1 style="font-family: 'Outfit', sans-serif; font-size: 36px; letter-spacing: -0.5px;">Strategic Intelligence Hub</h1>
                <p style="color: var(--text-secondary); font-size: 16px; margin-top: 8px;">Autonomous competitive research & ecosystem mapping engine.</p>
            </div>
            <div id="header-status-badge" class="status-pill" style="background: {{ system_state.bg }}; color: {{ system_state.color }}; border-color: rgba(255,255,255,0.1); font-size: 12px; display: flex; align-items: center; gap: 8px; padding: 8px 16px;">
                <span id="header-status-dot" class="animate-pulse" style="width: 8px; height: 8px; background: {{ system_state.color }}; border-radius: 50%;"></span>
                SYSTEM STATUS: <span id="header-status-text">{{ system_state.status }}</span>
            </div>
        </header>

        <section class="glass-card animate-in" style="animation-delay: 0.1s;">
            <div class="card-header">
                <h2 class="card-title"><i data-lucide="zap" style="color: var(--accent-orange)"></i> Intelligence Capture</h2>
                <p class="card-subtitle">Deploy the deep scraper to analyze any website or Zoho partner profile.</p>
            </div>
            
            <div class="search-area">
                <input type="text" id="partnerQuery" class="input-glow" placeholder="Enter brand name or official domain URL...">
                <button id="scrapeBtn" class="btn btn-primary" onclick="scrapePartner()" style="width: auto; padding: 0 32px;">
                    Analyze Now
                </button>
            </div>

            <div class="advanced-trigger" onclick="toggleAdvanced()" style="margin-bottom: 12px;">
                <i data-lucide="chevron-right" id="adv-arrow" size="14"></i> Configure Extraction Parameters & Bypass Links
            </div>

            <div id="competitor-logic-container" style="padding: 16px; background: rgba(56, 189, 248, 0.05); border: 1px solid rgba(56, 189, 248, 0.1); border-radius: 12px; margin-bottom: 20px;">
                <label style="cursor: pointer; display: flex; align-items: center; gap: 12px;">
                    <input type="checkbox" id="is-competitor" onchange="toggleCompetitor()" style="width: 18px; height: 18px; accent-color: var(--accent-orange);"> 
                    <span style="font-size: 14px; font-weight: 600;">Map as Competitor to a Baseline Target</span>
                </label>
                <div id="parent-selector-container" style="display: none; margin-top: 16px;">
                    <span class="nav-label" style="font-size: 10px;">Select Parent Company</span>
                    <select id="parent-company" class="input-glow" style="padding: 10px; font-size: 13px; width: 100%; background: rgba(2, 6, 23, 0.9);">
                        <option value="">-- Select Main Target --</option>
                    </select>
                </div>
            </div>
            
            <div class="advanced-panel" id="advanced-options">
                
                <div>
                    <label class="nav-label" style="font-size: 10px;">Blog Discovery Bypass</label>
                    <input type="text" id="manual-blog" class="input-glow" style="padding: 12px;" placeholder="/insights">
                </div>
                <div>
                    <label class="nav-label" style="font-size: 10px;">Case Study Bypass</label>
                    <input type="text" id="manual-case" class="input-glow" style="padding: 12px;" placeholder="/success-stories">
                </div>
                <div>
                    <label class="nav-label" style="font-size: 10px;">Social: LinkedIn</label>
                    <input type="text" id="manual-linkedin" class="input-glow" style="padding: 12px;" placeholder="https://...">
                </div>
                <div>
                    <label class="nav-label" style="font-size: 10px;">Social: YouTube</label>
                    <input type="text" id="manual-youtube" class="input-glow" style="padding: 12px;" placeholder="https://...">
                </div>
            </div>

            <div id="scrapeStatus" style="display: none; margin-top: 24px;">
                <div id="scrapeLoading" class="animate-in" style="color: var(--accent-blue); display: flex; align-items: center; gap: 10px; font-size: 14px;">
                    <i data-lucide="loader-2" class="animate-spin" size="18"></i> <span id="scrape-text">Initializing extraction...</span>
                </div>
                <div id="scrapeSuccess" class="status-pill animate-in" style="background: rgba(34, 197, 94, 0.1); color: #4ade80; border-color: rgba(34, 197, 94, 0.2); display: none;"></div>
                <div id="scrapeError" class="status-pill animate-in" style="background: rgba(239, 68, 68, 0.1); color: #f87171; border-color: rgba(239, 68, 68, 0.2); display: none;"></div>
            </div>
        </section>

        <div class="grid-dashboard">
            <section class="glass-card animate-in" style="animation-delay: 0.2s;">
                <div class="card-header" style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <h2 class="card-title"><i data-lucide="database" size="20"></i> Intelligence Bank</h2>
                        <p class="card-subtitle">Stored competitive data available for mapping.</p>
                    </div>
                    <button class="status-pill" onclick="toggleAllHistory()" id="toggleHistoryBtn" style="cursor: pointer; background: rgba(255,255,255,0.05);">0 Records</button>
                </div>
                <div id="history-list" class="list-container"></div>
                <div id="history-more-btn" class="toggle-view-btn" onclick="toggleAllHistory()">+ View Full Database</div>
            </section>

            <section class="glass-card animate-in" style="animation-delay: 0.3s;">
                <div class="card-header" style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <h2 class="card-title"><i data-lucide="file-text" size="20"></i> Strategic Reports</h2>
                        <p class="card-subtitle">Generated market maps and gap analyses.</p>
                    </div>
                    <button class="status-pill" onclick="toggleAllReports()" id="toggleReportsBtn" style="cursor: pointer; background: rgba(255,255,255,0.05);">0 Reports</button>
                </div>
                <div id="report-list" class="list-container"></div>
                <div id="report-more-btn" class="toggle-view-btn" onclick="toggleAllReports()">+ View All Reports</div>
            </section>
        </div>
    </main>

    <script>
        lucide.createIcons();
        let showAllHistory = false;
        let showAllReports = false;

        window.onload = () => {
            loadHistory();
            loadReports();
            loadParentCompanies();
        };

        function toggleAllHistory() { showAllHistory = !showAllHistory; loadHistory(); }
        function toggleAllReports() { showAllReports = !showAllReports; loadReports(); }

        function toggleAdvanced() {
            const opt = document.getElementById('advanced-options');
            const arrow = document.getElementById('adv-arrow');
            const isOpen = opt.style.display === 'grid';
            opt.style.display = isOpen ? 'none' : 'grid';
            arrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(90deg)';
            if (!isOpen) loadParentCompanies();
        }

        function toggleCompetitor() {
            const isComp = document.getElementById('is-competitor').checked;
            document.getElementById('parent-selector-container').style.display = isComp ? 'block' : 'none';
        }

        async function loadParentCompanies() {
            const sel = document.getElementById('parent-company');
            try {
                const response = await fetch('/list-partners');
                const data = await response.json();
                sel.innerHTML = '<option value="">-- Select Main Target --</option>';
                data.partners.filter(p => p.is_base).forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p.name;
                    opt.textContent = p.name;
                    sel.appendChild(opt);
                });
            } catch (e) { }
        }

        async function loadHistory() {
            const list = document.getElementById('history-list');
            const btn = document.getElementById('toggleHistoryBtn');
            const moreBtn = document.getElementById('history-more-btn');
            try {
                const res = await fetch('/list-partners');
                const data = await res.json();
                const partners = data.partners || [];
                btn.innerText = `${partners.length} Records`;
                
                const display = showAllHistory ? partners : partners.slice(0, 4);
                list.innerHTML = display.map(p => `
                    <div class="list-item">
                        <div class="item-main">
                            <span class="item-title">${p.name}</span>
                            <span class="item-subtitle">${p.parent ? 'Competitor to ' + p.parent : 'Entity ID: ' + p.id}</span>
                        </div>
                        <i data-lucide="${p.parent ? 'shield-alert' : 'check-circle'}" size="14" style="color: ${p.parent ? 'var(--accent-orange)' : 'var(--accent-blue)'}"></i>
                    </div>
                `).join('') || '<div style="opacity: 0.5; text-align: center; padding: 20px;">No records found.</div>';
                
                if (moreBtn) {
                    moreBtn.style.display = partners.length > 4 ? 'block' : 'none';
                    moreBtn.innerText = showAllHistory ? '- Show Less' : `+ View Full Database (${partners.length})`;
                }

                lucide.createIcons();

                const partnerSelectors = document.querySelectorAll('.partner-select');
                partnerSelectors.forEach(sel => {
                    const cur = sel.value;
                    const isSync = sel.id === 'sync-select';
                    sel.innerHTML = isSync ? '<option value="">(Global Ecosystem Sync)</option>' : '<option value="">(Default: Trigya)</option>';
                    partners.forEach(p => {
                        const opt = document.createElement('option');
                        opt.value = p.name;
                        opt.textContent = p.display_name || p.name;
                        if (p.name === cur) opt.selected = true;
                        sel.appendChild(opt);
                    });
                });
            } catch (e) {}
        }

        async function loadReports() {
            const list = document.getElementById('report-list');
            const btn = document.getElementById('toggleReportsBtn');
            const moreBtn = document.getElementById('report-more-btn');
            try {
                const res = await fetch('/list-reports');
                const data = await res.json();
                const reports = data.reports || [];
                btn.innerText = `${reports.length} Reports`;
                
                const display = showAllReports ? reports : reports.slice(0, 4);
                list.innerHTML = display.map(f => `
                    <div class="list-item">
                        <a href="/download/${f}" class="item-title" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 8px;">
                            <i data-lucide="download" size="14"></i> ${f}
                        </a>
                        <span class="status-pill" style="font-size: 9px;">PDF</span>
                    </div>
                `).join('') || '<div style="opacity: 0.5; text-align: center; padding: 20px;">No reports yet.</div>';
                
                if (moreBtn) {
                    moreBtn.style.display = reports.length > 4 ? 'block' : 'none';
                    moreBtn.innerText = showAllReports ? '- Show Less' : `+ View All Reports (${reports.length})`;
                }

                lucide.createIcons();
            } catch (e) {}
        }

        async function scrapePartner() {
            const query = document.getElementById('partnerQuery').value;
            if (!query) return;

            const btn = document.getElementById('scrapeBtn');
            const statusBox = document.getElementById('scrapeStatus');
            const loading = document.getElementById('scrapeLoading');
            const statusText = document.getElementById('scrape-text');
            const success = document.getElementById('scrapeSuccess');
            const error = document.getElementById('scrapeError');
            
            btn.disabled = true;
            statusBox.style.display = 'block';
            loading.style.display = 'flex';
            statusText.innerText = 'Initializing extraction...';
            success.style.display = 'none';
            error.style.display = 'none';

            const initialRes = await fetch('/list-partners');
            const initialData = await initialRes.json();
            const initialCount = (initialData.partners || []).length;

            const manualLinks = {
                blog_url: document.getElementById('manual-blog').value,
                case_study_url: document.getElementById('manual-case').value,
                youtube_url: document.getElementById('manual-youtube').value,
                linkedin_url: document.getElementById('manual-linkedin').value
            };

            const parent = document.getElementById('is-competitor').checked ? document.getElementById('parent-company').value : '';

            try {
                let url = `/scrape-partner?query=${encodeURIComponent(query)}&manual=${encodeURIComponent(JSON.stringify(manualLinks))}`;
                if (parent) url += `&parent_company=${encodeURIComponent(parent)}`;
                
                const res = await fetch(url);
                const data = await res.json();
                
                if (data.success) {
                    let attempts = 0;
                    const maxAttempts = 120;
                    const initialMaxMtime = Math.max(0, ...((initialData.partners || []).map(p => p.mtime || 0)));
                    
                    const poll = setInterval(async () => {
                        attempts++;
                        const currentRes = await fetch('/list-partners');
                        const currentData = await currentRes.json();
                        const currentCount = (currentData.partners || []).length;
                        const currentMaxMtime = Math.max(0, ...((currentData.partners || []).map(p => p.mtime || 0)));

                        // Check background task health
                        const taskRes = await fetch('/task-status/scrape');
                        const taskData = await taskRes.json();
                        
                        if (taskData.status === 'failed') {
                            clearInterval(poll);
                            loading.style.display = 'none';
                            error.innerText = "Capture Failed: " + taskData.error;
                            error.style.display = 'inline-block';
                            btn.disabled = false;
                            return;
                        }

                        if (currentCount > initialCount || currentMaxMtime > initialMaxMtime || attempts >= maxAttempts) {
                            clearInterval(poll);
                            loading.style.display = 'none';
                            success.innerText = "SUCCESS: Intelligence Captured & Synthesized.";
                            success.style.display = 'inline-block';
                            btn.disabled = false;
                            loadHistory();
                        } else {
                            if (attempts > 6) statusText.innerText = 'Deep Content Extraction...';
                            if (attempts > 24) statusText.innerText = 'Analyzing & Saving Entities...';
                        }
                    }, 5000);
                }
            } catch (e) {
                loading.style.display = 'none';
                error.innerText = "Extraction initiated. Check system logs.";
                error.style.display = 'inline-block';
                btn.disabled = false;
                setTimeout(loadHistory, 10000);
            }
        }

        async function syncCollections() {
            const baseline = document.getElementById('sync-select').value;
            const btn = document.getElementById('sync-btn');
            btn.style.opacity = '0.5';
            btn.innerHTML = '<i data-lucide="loader-2" class="animate-spin" size="18"></i> Synchronizing...';
            try {
                let url = '/sync';
                if (baseline) url += `?baseline=${encodeURIComponent(baseline)}`;
                const res = await fetch(url);
                const data = await res.json();
                console.log("Sync triggered for: " + (baseline || "Global"));
            } catch (e) { }
            finally {
                setTimeout(() => { 
                    btn.disabled = false; 
                    btn.style.opacity = '1';
                    btn.innerHTML = '<i data-lucide="refresh-cw" size="18"></i> Sync Target Data'; 
                    lucide.createIcons();
                }, 3000);
            }
        }

        async function runBulkReport() {
            const baseline = document.getElementById('baseline-select').value;
            const btn = document.getElementById('bulk-btn');
            const status = document.getElementById('status-text');
            const progressBar = document.getElementById('report-progress-bar');
            const progressContainer = document.getElementById('report-progress-container');

            btn.disabled = true;
            status.textContent = "Deploying Intelligence Mapper...";
            progressContainer.style.display = 'block';
            progressBar.style.width = '10%';

            try {
                const hResInit = await fetch('/list-reports');
                const hDataInit = await hResInit.json();
                const initialNewest = hDataInit.reports && hDataInit.reports.length > 0 ? hDataInit.reports[0] : null;

                const res = await fetch(`/run-bulk?baseline=${encodeURIComponent(baseline)}`);
                const data = await res.json();

                if (data.success) {
                    let hasDownloaded = false;
                    let progress = 10;
                    let attempts = 0;
                    
                    const pollInterval = setInterval(async () => {
                        attempts++;
                        if (progress < 95) {
                            progress += 1;
                            progressBar.style.width = progress + '%';
                            status.textContent = "Synthesizing Comparative Analysis...";
                        }
                        
                        const hRes = await fetch('/list-reports');
                        const hData = await hRes.json();
                        const currentNewest = hData.reports && hData.reports.length > 0 ? hData.reports[0] : null;

                        // Check background task health
                        const taskRes = await fetch('/task-status/report');
                        const taskData = await taskRes.json();

                        if (taskData.status === 'failed') {
                            clearInterval(pollInterval);
                            progressBar.style.width = '0%';
                            status.textContent = "Report Failed: " + taskData.error;
                            status.style.color = "#f87171";
                            btn.disabled = false;
                            setTimeout(() => { progressContainer.style.display = 'none'; status.textContent = ""; status.style.color = ""; }, 15000);
                            return;
                        }

                        if (currentNewest && currentNewest !== initialNewest && !hasDownloaded) {
                            hasDownloaded = true;
                            clearInterval(pollInterval);
                            progressBar.style.width = '100%';
                            status.textContent = "REPORT READIED: " + currentNewest;
                            status.style.color = "#4ade80";
                            
                            const link = document.createElement('a');
                            link.href = `/download/${currentNewest}`;
                            link.download = currentNewest;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            
                            loadReports();
                            btn.disabled = false;
                            setTimeout(() => { progressContainer.style.display = 'none'; status.textContent = ""; status.style.color = ""; }, 8000);
                        } else if (attempts > 60) {
                            clearInterval(pollInterval);
                            progressBar.style.width = '0%';
                            status.textContent = "FAILURE: Intelligence Mapping Timed Out.";
                            status.style.color = "#f87171";
                            btn.disabled = false;
                            setTimeout(() => { progressContainer.style.display = 'none'; status.textContent = ""; status.style.color = ""; }, 10000);
                        }
                    }, 3000);
                } else {
                    throw new Error(data.error || "Launch failed");
                }
            } catch (e) {
                status.textContent = 'CRITICAL FAILURE: ' + e.message;
                status.style.color = "#f87171";
                btn.disabled = false;
                setTimeout(() => { progressContainer.style.display = 'none'; status.textContent = ""; status.style.color = ""; }, 10000);
            }
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    print(f"[*] Serving Dashboard from: {os.getcwd()}")
    return render_template_string(HTML_TEMPLATE, system_state=system_state)

ADMIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Intelligence Admin Portal</title>
    <style>
        :root { --bg: #020617; --card: #1e293b; --text: #f8fafc; --accent: #f97316; }
        body { background: var(--bg); color: var(--text); font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: var(--card); padding: 40px; border-radius: 24px; width: 400px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.5); }
        h1 { margin-bottom: 30px; font-size: 24px; letter-spacing: -0.5px; }
        .btn-list { display: flex; flex-direction: column; gap: 15px; }
        .btn { padding: 15px; border-radius: 12px; border: none; cursor: pointer; font-weight: bold; font-size: 16px; transition: 0.3s; color: white; }
        .btn-op { background: #16a34a; }
        .btn-main { background: #d97706; }
        .btn-lim { background: #dc2626; }
        .btn:hover { transform: scale(1.02); opacity: 0.9; }
        .status-preview { margin-top: 30px; padding: 10px; border-radius: 8px; font-size: 14px; background: rgba(255,255,255,0.05); }
    </style>
</head>
<body>
    <div class="card">
        <h1>System Control Panel</h1>
        <div class="btn-list">
            <button class="btn btn-op" onclick="update('OPERATIONAL', '#4ade80', 'rgba(34, 197, 94, 0.1)')">Set Operational</button>
            <button class="btn btn-main" onclick="update('MAINTENANCE', '#fbbf24', 'rgba(245, 158, 11, 0.1)')">Set Maintenance</button>
            <button class="btn btn-lim" onclick="update('LIMITED', '#f87171', 'rgba(239, 68, 68, 0.1)')">Set Limited</button>
        </div>
        <div id="status" class="status-preview">Current Status: {{ status }}</div>
        <p style="margin-top: 20px; font-size: 12px; opacity: 0.5;"><a href="/" style="color: inherit;">Back to Dashboard</a></p>
    </div>
    <script>
        async function update(status, color, bg) {
            await fetch(`/update-status?status=${status}&color=${encodeURIComponent(color)}&bg=${encodeURIComponent(bg)}`);
            document.getElementById('status').innerText = 'Current Status: ' + status;
            document.getElementById('status').style.color = color;
        }
    </script>
</body>
</html>
"""

@app.route('/admin')
def admin():
    return render_template_string(ADMIN_TEMPLATE, status=system_state['status'])

@app.route('/update-status')
def update_status():
    global system_state
    system_state['status'] = request.args.get('status', 'OPERATIONAL')
    system_state['color'] = request.args.get('color', '#4ade80')
    system_state['bg'] = request.args.get('bg', 'rgba(34, 197, 94, 0.1)')
    return jsonify({"success": True})

@app.route('/logo')
def get_logo():
    return send_from_directory(os.getcwd(), "logo.webp")

@app.route('/task-status/<task_type>')
def task_status(task_type):
    log_path = f"{task_type}_last.log"
    proc = active_tasks.get(task_type)
    
    # 1. Check log file for completion/failure status first (most reliable)
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                content = f.read()
                if "SUCCESS: ANALYSIS COMPLETE" in content or "SUCCESS: SYNC COMPLETE" in content:
                    return jsonify({"status": "completed", "message": "Task finished successfully."})
                
                # Check for crash/error signatures
                if "Traceback" in content or "NameError" in content or "Error" in content:
                    # Extract last relevant error line
                    lines = [l.strip() for l in content.splitlines() if l.strip()]
                    error_msg = lines[-1] if lines else "Unknown error in logs."
                    return jsonify({"status": "failed", "error": error_msg})
        except: pass

    # 2. If no definitive log status, check the active process
    if proc is not None:
        retcode = proc.poll()
        if retcode is None:
            return jsonify({"status": "running"})
        if retcode == 0:
            return jsonify({"status": "completed"})
        else:
            return jsonify({"status": "failed", "error": f"Process exited with code {retcode}"})
    
    return jsonify({"status": "idle"})

@app.route('/scrape-partner')
def scrape_partner():
    query = request.args.get('query')
    manual = request.args.get('manual')
    parent = request.args.get('parent_company')
    try:
        cmd = ["python", "main.py", "--partner", query]
        if manual:
            cmd.extend(["--manual-links", manual])
        if parent:
            cmd.extend(["--parent-company", parent])
        
        # Log to file to capture errors
        log_f = open("scrape_last.log", "w", encoding="utf-8")
        active_tasks["scrape"] = subprocess.Popen(cmd, stdout=log_f, stderr=log_f)
        return jsonify({"success": True, "message": "Scrape started in background"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/run-bulk')
def run_bulk():
    baseline = request.args.get('baseline')
    try:
        cmd = ["python", "main.py", "--bulk"]
        if baseline:
            cmd.extend(["--baseline", baseline])

        # Log to file to capture errors
        log_f = open("report_last.log", "w", encoding="utf-8")
        active_tasks["report"] = subprocess.Popen(cmd, stdout=log_f, stderr=log_f)
        return jsonify({"success": True, "message": "Report generation started in background."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/sync')
def sync():
    baseline = request.args.get('baseline')
    try:
        cmd = ["python", "main.py", "--sync"]
        if baseline:
            cmd.extend(["--baseline", baseline])
        
        active_tasks["sync"] = subprocess.Popen(cmd)
        return jsonify({"success": True, "message": f"Sync started for {baseline or 'Global'} in background."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/list-partners')
def list_partners():
    partners_dict = {}
    
    if os.path.exists(OUTPUT_DIR):
        # Recursive walk to find all partner JSON files
        for root, dirs, files in os.walk(OUTPUT_DIR):
            for f in files:
                if f.endswith(".json"):
                    file_path = os.path.join(root, f)
                    try:
                        with open(file_path, "r", encoding="utf-8") as file:
                            data = json.load(file)
                            name = data.get("name", "Unknown")
                            partner_id = data.get("partner_id", "N/A")
                            parent = data.get("parent_company")
                            mtime = os.path.getmtime(file_path)
                            # STRICT FILTER: Check both JSON data AND folder structure
                            is_competitor_folder = "competitors" in root.lower()
                            is_base = (parent is None or parent == "") and not is_competitor_folder
                            
                            display_name = f"{name} (Competitor to {parent})" if parent else name
                            if is_competitor_folder and not parent:
                                # Try to derive parent from folder name if JSON is missing it
                                parts = root.split(os.sep)
                                if "competitors" in parts:
                                    idx = parts.index("competitors")
                                    if idx > 0:
                                        folder_parent = parts[idx-1]
                                        display_name = f"{name} (Competitor to {folder_parent})"

                            # Use name+id as key to dedup but allow same-name partners with different IDs
                            key = f"{name}_{partner_id}"
                            partners_dict[key] = {
                                "name": name,
                                "display_name": display_name,
                                "id": partner_id,
                                "is_base": is_base,
                                "parent": parent,
                                "mtime": mtime
                            }
                    except Exception as e:
                        print(f"Error loading {f}: {e}")
    
    # Convert to list and sort
    all_partners = list(partners_dict.values())
    # Filter to only show PRIMARY targets (is_base=True)
    primary_only = [p for p in all_partners if p.get('is_base')]
    
    primary_only.sort(key=lambda x: str(x.get('name') or 'Unknown').lower())
    print(f"[*] Serving {len(primary_only)} primary partners (filtered from {len(all_partners)})")
    return jsonify({"partners": primary_only})

@app.route('/list-reports')
def list_reports():
    try:
        if not os.path.exists(REPORT_DIR):
            return jsonify({"reports": []})
        
        # Get all PDFs, sorted by creation time (newest first)
        files = [f for f in os.listdir(REPORT_DIR) if f.endswith('.pdf')]
        files.sort(key=lambda x: os.path.getctime(os.path.join(REPORT_DIR, x)), reverse=True)
        
        return jsonify({"reports": files})
    except Exception as e:
        return jsonify({"reports": [], "error": str(e)})

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(REPORT_DIR, filename, as_attachment=True, download_name=filename)

# --- SECURE TRIGGER API ---
@app.route('/api/trigger-scrape', methods=['POST'])
def api_trigger_scrape():
    """External API to trigger a scrape session remotely."""
    try:
        # 1. Verify API Key
        provided_key = request.headers.get("X-API-Key")
        master_key = os.getenv("SCRAPER_API_KEY")
        
        if not master_key or provided_key != master_key:
            return jsonify({"error": "Unauthorized. Invalid or missing X-API-Key."}), 401
            
        # 2. Extract parameters
        data = request.json or {}
        partner_name = data.get("partner_name")
        parent_company = data.get("parent_company")
        
        if not partner_name:
            return jsonify({"error": "Missing 'partner_name' in request body."}), 400
            
        # 3. Prevent duplicate tasks
        if active_tasks["scrape"] and active_tasks["scrape"].poll() is None:
            return jsonify({"error": "A scraping task is already in progress. Please wait."}), 429
            
        # 4. Trigger Scrape via Subprocess
        print(f"[*] API Triggered Scrape: {partner_name} (Parent: {parent_company})")
        cmd = [sys.executable, "main.py", "--partner", partner_name, "--headless"]
        if parent_company:
            cmd.extend(["--parent_company", parent_company])
            
        log_f = open("scrape_last.log", "w", encoding="utf-8")
        process = subprocess.Popen(cmd, stdout=log_f, stderr=log_f)
        active_tasks["scrape"] = process
        
        return jsonify({
            "message": "Scrape task initialized successfully.",
            "partner": partner_name,
            "parent_company": parent_company,
            "status": "RUNNING",
            "status_check_url": "/api/status/scrape"
        }), 202
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/trigger-report', methods=['POST'])
def api_trigger_report():
    """External API to trigger report generation remotely."""
    try:
        # 1. Verify API Key
        provided_key = request.headers.get("X-API-Key")
        master_key = os.getenv("REPORT_API_KEY")
        
        if not master_key or provided_key != master_key:
            return jsonify({"error": "Unauthorized. Invalid or missing X-API-Key."}), 401
            
        # 2. Extract parameters
        data = request.json or {}
        baseline_company = data.get("baseline_company")
        
        if not baseline_company:
            return jsonify({"error": "Missing 'baseline_company' in request body."}), 400
            
        # 3. Prevent duplicate tasks
        if active_tasks["report"] and active_tasks["report"].poll() is None:
            return jsonify({"error": "A report generation task is already in progress. Please wait."}), 429
            
        # 4. Trigger Report via Subprocess
        # This uses the existing --bulk --baseline logic which automatically handles peer relations
        print(f"[*] API Triggered Report: {baseline_company}")
        cmd = [sys.executable, "main.py", "--bulk", "--baseline", baseline_company]
        
        # Log to file
        log_f = open("report_last.log", "w", encoding="utf-8")
        process = subprocess.Popen(cmd, stdout=log_f, stderr=log_f)
        active_tasks["report"] = process
        
        return jsonify({
            "message": "Report generation initialized successfully.",
            "baseline": baseline_company,
            "status": "RUNNING",
            "status_check_url": "/api/status/report",
            "info": "Peer relationships will be automatically adjusted based on selection."
        }), 202
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/trigger-sync', methods=['POST'])
def api_trigger_sync():
    """External API to trigger data synchronization remotely."""
    try:
        # 1. Verify API Key
        provided_key = request.headers.get("X-API-Key")
        master_key = os.getenv("SYNC_API_KEY")
        
        if not master_key or provided_key != master_key:
            return jsonify({"error": "Unauthorized. Invalid or missing X-API-Key."}), 401
            
        # 2. Extract parameters
        data = request.json or {}
        baseline = data.get("baseline")
        
        # 3. Prevent duplicate tasks
        if active_tasks["sync"] and active_tasks["sync"].poll() is None:
            return jsonify({"error": "A synchronization task is already in progress. Please wait."}), 429
            
        # 4. Trigger Sync via Subprocess
        print(f"[*] API Triggered Sync: {baseline or 'Global Ecosystem'}")
        cmd = [sys.executable, "main.py", "--sync"]
        if baseline:
            cmd.extend(["--baseline", baseline])
            
        log_f = open("sync_last.log", "w", encoding="utf-8")
        process = subprocess.Popen(cmd, stdout=log_f, stderr=log_f)
        active_tasks["sync"] = process
        
        return jsonify({
            "message": "Sync task initialized successfully.",
            "baseline": baseline or "Global Ecosystem",
            "status": "RUNNING",
            "status_check_url": "/api/status/sync"
        }), 202
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/status/<task_type>', methods=['GET'])
def api_task_status(task_type):
    """External API to check task status with authentication."""
    try:
        # 1. Verify API Key (using any of the relevant keys)
        provided_key = request.headers.get("X-API-Key")
        keys = [os.getenv("SCRAPER_API_KEY"), os.getenv("REPORT_API_KEY"), os.getenv("SYNC_API_KEY")]
        
        if not provided_key or provided_key not in keys:
            return jsonify({"error": "Unauthorized. Invalid or missing X-API-Key."}), 401
            
        # 2. Reuse the existing status logic
        return task_status(task_type)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
