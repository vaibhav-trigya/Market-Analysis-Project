import json
import os
import sys
from google import genai
from google.genai import types
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class PartnerAnalyzer:
    """Uses Google Gemini for all analysis. Generates structured JSON for the report engine."""
    
    def __init__(self, gemini_key: str | None = None):
        # Gemini Init
        self.gemini_key = gemini_key or os.getenv("GEMINI_API_KEY")
        self.gemini_client = None
        if self.gemini_key:
            try:
                self.gemini_client = genai.Client(api_key=self.gemini_key)
                self.gemini_model = "gemini-2.5-flash"
            except Exception as e:
                print(f"[!] Gemini Initialization failed: {e}", file=sys.stderr)
        
        self.total_usage = {"gemini_tokens": 0}

    def _track_usage(self, response):
        try:
            if hasattr(response, 'usage_metadata'):
                self.total_usage["gemini_tokens"] += response.usage_metadata.total_token_count
        except: pass

    def _generate(self, prompt: str, system_instruction: str = None, json_mode: bool = False, temperature: float = 1.0) -> str | None:
        """Generation using Gemini."""
        res = None
        if self.gemini_client:
            try:
                config = {"temperature": temperature, "system_instruction": system_instruction}
                if json_mode: config["response_mime_type"] = "application/json"
                response = self.gemini_client.models.generate_content(model=self.gemini_model, contents=prompt, config=config)
                self._track_usage(response)
                res = response.text
            except Exception as e:
                print(f"[-] Gemini AI Error: {e}", file=sys.stderr)
        
        if res:
            # POST-PROCESSING: Hard removal of Banned Buzzwords
            banned = {
                "Technical Moat": "Technical Competitive Edge",
                "Ecosystem Authority": "Market Presence",
                "Strategic Synergy": "Strategic Alignment",
                "Market Friction": "Operational Resistance",
                "Service Diversification": "Service Expansion",
                "Actionable": "Measurable",
                "Revenue Scalability": "Growth Potential",
                "Digital Transformation": "Modernization"
            }
            for word, rep in banned.items():
                res = res.replace(word, rep).replace(word.lower(), rep.lower())
        return res

    def analyze(self, data: dict) -> str | None:
        """Standard summary for individual partner data."""
        prompt = f"Analyze this Zoho Partner data and provide a concise business summary.\nDATA:\n{json.dumps(data.get('overview', ''))}"
        return self._generate(prompt, system_instruction="You are a professional business analyst.")

    def compare(self, data1: dict, data2: dict) -> str | None:
        """Comparative analysis."""
        prompt = f"Compare {data1['name']} vs {data2['name']}.\nS1: {data1.get('analysis_summary')}\nS2: {data2.get('analysis_summary')}"
        return self._generate(prompt, system_instruction="You are a Zoho ecosystem expert.")

    def generate_competitive_report(self, trigya_data: dict, other_partners: list[dict]) -> str | None:
        """Optimized generation: Summarizes context before pass-through to reduce latency."""
        
        # Prune data to only what is needed for analysis
        def prune(d):
            overview = d.get("overview", {})
            if not isinstance(overview, dict): overview = {}
            
            summary = d.get("analysis_summary")
            if not summary:
                summary = overview.get("description", "")
            
            return {
                "name": str(d.get("name", "Unknown")),
                "summary": str(summary)[:2500],
                "scores": d.get("scores") if isinstance(d.get("scores"), dict) else {},
                "certifications": overview.get("certifications", []),
                "industries": d.get("industries", [])[:10]
            }

        trigya_context = json.dumps(prune(trigya_data), indent=2)
        competitor_details = json.dumps([prune(p) for p in other_partners], indent=2)

        prompt = f"""
        You are generating a FORMAL SENIOR-LEVEL COMPETITIVE INTELLIGENCE REPORT.
        
        ZERO HALLUCINATION RULE: Use ONLY the {len(other_partners) + 1} companies provided (Baseline + {len(other_partners)} competitors). Do NOT invent any extra companies whatsoever.

        ANALYTICAL DEPTH REQUIREMENTS (ALL MANDATORY):

        1. STRATEGIC INTELLIGENCE LAYER: Use proper strategic frameworks including "Technical Moat", "Ecosystem Authority", "Market Friction", "Revenue Scalability" — but only when backed by specific data from the provided summaries. e.g. "Competitor A faces market friction due to lack of ecosystem authority demonstrated by absence of multi-platform client case studies."

        2. POSITIONING CLARITY: The report must establish a clear battle narrative — who is winning, who is losing, and WHY. e.g. "Competitor B = Specialized Efficiency Engine. Baseline = Ecosystem Player. This positions them as non-overlapping in SMB but directly competing in mid-market."

        3. MARKET INSIGHT DEPTH: Identify the dominant market trend evident from the data (e.g. "Market trend: specialization vs ecosystem integration — clients choosing between depth vs breadth"). This must appear in cohort and interpretation sections.

        4. PERFORMANCE INDEX FORMULA: In 'scoring_methodology', define explicit weightages. e.g. "Tech Stack (30%) + Client Proof Volume (25%) + Market Reach (20%) + Trust Index (15%) + Growth Velocity (10%) = 100. Score interpretation: 80+ = Market Leader."

        5. STRATEGIC INTERPRETATION (Long-form): Must include future implications and specific growth paths. e.g. "Competitor C must expand via API integrations to scale — single-product depth is a ceiling, not a floor."

        6. GTM STRATEGY ANALYSIS (COMPARATIVE): Analyze how competitors are winning through their ecosystem and selling models VS THE BASELINE. Must cover: (a) Channel strategy (partners vs direct) comparison, (b) Inbound vs outbound dynamics relative to baseline, and (c) ecosystem leverage gaps.
        
        7. PRODUCT BENCHMARKING COVERAGE (ONE PER COMPANY): You MUST include the [BASELINE] company and all [COMPETITORS]. However, you MUST only provide exactly ONE primary solution or service entry for each company. Select the 'Flagship' or 'Most Efficient' solution for each entity to ensure a focused, high-level comparison.

        REQUIRED JSON STRUCTURE:
        {{
          "scoring_methodology": "Define EXPLICIT weightages (e.g. Tech 30%, Proof 25%, Reach 20%, Trust 15%, Velocity 10%) and explain what each score means for market position.",
          "executive_summary": "3 dense paragraphs. Must include: (1) current market battle framing, (2) who is leading and the data behind it, (3) the dominant trend.",
          "cohort": "Strategic battle framing analysis. Name the 'war' (e.g. Specialization vs Ecosystem). Explain each entity's position in that war with specific evidence.",
          "performance_index_context": "Explain score differences using formula. Which specific data points drove each number up or down.",
          "radar_context": "Technical capability map from case study data vs market footprint. Name specific services/products.",
          "interpretation": "Long-form (4-5 paragraphs). Cover: (1) current positioning battle, (2) market friction points for baseline, (3) ecosystem dynamics, (4) future implications if baseline stays on current path, (5) strategic path recommendation.",
          "leaders": [
            {{ "name": "Partner", "strength": "Specific data-backed strength", "weakness": "Specific documented gap", "evidence": "Source name" }}
          ],
          "gap_analysis_context": "Explain where the baseline is losing market friction through lack of ecosystem authority vs competitors.",
          "gap": "Specific capability gaps vs the exact rivals provided. Quantify where possible.",
          "recommendations": [
            {{ "title": "Specific Strategic Project", "rationale": "Direct evidence-backed reasoning (50+ words) referencing specific rival advantage.", "implementation_steps": ["Specific step 1", "Specific step 2", "Specific step 3"], "impact": "Measurable future outcome." }}
          ],
          "path": [
            {{ "quarter": "Q1 (Months 1-3)", "milestone": "Specific measurable goal", "capabilities": "Core skills to build", "details": ["Task 1", "Task 2", "Task 3"] }},
            {{ "quarter": "Q2 (Months 4-6)", "milestone": "Specific measurable goal", "capabilities": "Core skills to build", "details": ["Task 1", "Task 2"] }},
            {{ "quarter": "Q3-Q4 (Months 7-12)", "milestone": "Market position target", "capabilities": "Advanced integration", "details": ["Task 1", "Task 2"] }}
          ],
          "gtm_strategy_analysis": {{
            "summary": "High-level comparative strategy analysis between baseline and leader cohort (2 paragraphs).",
            "channel_strategy": "Comparison of Direct vs Partner sales approaches between baseline and competitors.",
            "inbound_vs_outbound": "Lead generation breakdown and strategic delta between baseline and competitors.",
            "ecosystem_leverage": "Comparative analysis of how baseline vs competitors utilize the Zoho/Partner ecosystem."
          }},
          "product_benchmarking": [
            {{ "partner_name": "EXACT [BASELINE] Name", "solution_identified": "Flagship Solution Name", "target_vertical": "Industry", "efficiency_score": 90, "complexity_score": 30, "data_source": "Source" }},
            {{ "partner_name": "EXACT Competitor Name", "solution_identified": "Most Efficient Service", "target_vertical": "Industry", "efficiency_score": 85, "complexity_score": 40, "data_source": "Source" }}
          ],
          "comparison_matrix": [
            {{ "Company": "Partner", "Strength": "Specific technical moat or capability", "Weakness": "Specific documented gap", "Market_Focus": "Verified industry vertical" }}
          ],
          "scores": {{ "Tech_Stack": 80, "Client_Proof": 70, "Market_Reach": 60, "Trust_Index": 90, "Growth_Velocity": 50 }},
          "gap_metrics": {{ "Ecosystem_Reach": -30, "Case_Study_Volume": -20, "Integration_Depth": 10 }},
          "final_insight": "A high-level strategic directive (2-3 sentences) that answers: what must the baseline do NOW, and what happens if they don't. No fluff, no vague advice."
        }}

        DATA FOR AUDIT:
        [BASELINE] {trigya_context}
        [COMPETITORS] {competitor_details}
        """

        system_msg = (
            f"You are a Senior Partner at a top-tier strategy consultancy. "
            f"Your audience is C-suite executives. Use ONLY the {len(other_partners) + 1} companies provided — "
            f"hallucinating extra names is a critical failure. "
            f"Use strategic frameworks (Technical Moat, Ecosystem Authority, Market Friction) when backed by data. "
            f"The report must tell a clear story: who is winning, who is losing, and what to do about it."
        )
        return self._generate(prompt, system_instruction=system_msg, json_mode=True, temperature=0.3)

    def find_listing_links(self, website_url: str, links: list[dict]) -> dict:
        prompt = f"Identify Blog, Case Study, and Customer Stories URLs:\n{links[:50]}"
        res = self._generate(prompt, system_instruction="Return JSON: blog_url, case_study_url, customer_story_url.", json_mode=True)
        try: return json.loads(res) if res else {}
        except: return {}

    def summarize_content(self, title: str, raw_content: str) -> str:
        prompt = f"Summarize {title} into 50 words:\n{raw_content[:2000]}"
        return self._generate(prompt, system_instruction="You are a business writer.") or raw_content

    def find_social_links_with_ai(self, partner_name: str, website_url: str) -> dict:
        prompt = f"Find the official social media profile URLs for the company '{partner_name}' whose website is {website_url}."
        res = self._generate(prompt, system_instruction="Return JSON with keys: instagram, twitter, facebook, youtube, linkedin. If not known, use null.", json_mode=True)
        try: return json.loads(res) if res else {}
        except: return {}

    def extract_company_name_with_ai(self, url: str) -> str:
        prompt = f"What is the actual short company name for this website: {url}? Return only the name, no extra text."
        res = self._generate(prompt, system_instruction="Return the clean brand name (e.g. 'Apple' not 'Apple Inc.').")
        return res.strip() if res else url
