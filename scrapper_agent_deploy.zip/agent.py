import sys
import re
import hashlib
from urllib.parse import urljoin, urlparse
from playwright.sync_api import sync_playwright

# Constants
BASE_URL = "https://www.zoho.com"
PARTNER_LIST_URL = "https://www.zoho.com/partners/find-zoho-partner.html"
PARTNER_SEARCH_URL = "https://www.zoho.com/partners/find-zoho-partner.html"

# Import modularized functions
from extractors import (
    extract_name, extract_overview, extract_website, extract_linkedin,
    extract_customer_stories, extract_blogs, extract_case_studies,
    extract_from_external_website, extract_page_content, extract_from_manual_links,
    _collect_all_nav_links, _expand_nav_fully, extract_linkedin_from_external,
    extract_social_links, scrape_social_platform
)
from analyzer import PartnerAnalyzer

class ZohoPartnerAgent:
    def __init__(self, partner_name: str | None = None, headless: bool = True, analyzer: PartnerAnalyzer | None = None, parent_company: str | None = None):
        self.partner_name = partner_name
        self.headless = headless
        self.analyzer = analyzer or PartnerAnalyzer()
        self.parent_company = parent_company
        self.browser = None
        self.page = None

    def _launch(self, playwright):
        self.browser = playwright.chromium.launch(headless=self.headless)
        context = self.browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1366, "height": 768},
            ignore_https_errors=True,
            java_script_enabled=True,
            device_scale_factor=1,
            has_touch=False,
            is_mobile=False,
            extra_http_headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Cache-Control": "max-age=0"
            }
        )
        self.page = context.new_page()
        # Disable webdriver flag
        self.page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

    def _safe_goto(self, url: str, timeout: int = 25000, wait_until: str = "domcontentloaded"):
        """Attempt to navigate to a URL with a fast failover strategy. Returns response or None."""
        try:
            # Try primary navigation with a shorter timeout
            return self.page.goto(url, wait_until=wait_until, timeout=timeout)
        except Exception as e:
            # If it's a timeout, try the most lenient fallback immediately
            if "Timeout" in str(e) or "net::ERR" in str(e):
                print(f"[*] Page load slow for {url}, using fast-content fallback...", file=sys.stderr)
                try:
                    # Fallback: Just wait for the server to respond (commit)
                    return self.page.goto(url, wait_until="commit", timeout=15000)
                except: pass
            print(f"[-] Navigation failed for {url}: {e}", file=sys.stderr)
            return None

    def _close(self):
        if self.browser:
            self.browser.close()

    def _safe_text(self, selector: str, root=None) -> str | None:
        ctx = root if root else self.page
        try:
            el = ctx.query_selector(selector)
            return el.inner_text().strip() if el else None
        except Exception:
            return None

    def _safe_attr(self, selector: str, attr: str, root=None) -> str | None:
        ctx = root if root else self.page
        try:
            el = ctx.query_selector(selector)
            return el.get_attribute(attr) if el else None
        except Exception:
            return None

    def _absolute_url(self, href: str | None) -> str | None:
        if not href: return None
        href = href.strip()
        if href.startswith("http"): return href
        if href.startswith("//"): return "https:" + href
        
        # Use current page URL as base if available, otherwise fallback to BASE_URL
        base = self.page.url if self.page else BASE_URL
        return urljoin(base, href)

    def _scroll_to_bottom(self):
        self.page.evaluate("""
            async () => {
                await new Promise(resolve => {
                    let total = 0;
                    const step = 400;
                    const timer = setInterval(() => {
                        window.scrollBy(0, step);
                        total += step;
                        if (total >= document.body.scrollHeight) {
                            clearInterval(timer);
                            resolve();
                        }
                    }, 150);
                });
            }
        """)
        self.page.wait_for_timeout(1500)
    
    def _try_switch_to_english(self):
        """Attempts to find and click an English language switcher on the page."""
        print("[*] Checking for English language switcher...", file=sys.stderr)
        
        # 1. Look for obvious text-based links
        en_selectors = [
            "a:has-text('English')", 
            "a:has-text('EN')", 
            "button:has-text('English')",
            "a[aria-label*='English' i]",
            "a[title*='English' i]",
            "a[href*='/en/']",
            "a[href*='lang=en']"
        ]
        
        for selector in en_selectors:
            try:
                el = self.page.locator(selector).first
                if el.count() > 0 and el.is_visible():
                    print(f"[+] Found language switcher: {selector}. Switching to English...", file=sys.stderr)
                    el.click()
                    self.page.wait_for_load_state("domcontentloaded", timeout=15000)
                    self.page.wait_for_timeout(2000)
                    return True
            except Exception:
                continue
        
        return False

    def apply_filters(self):
        print("[*] Navigating to partner list and applying experience filters...", file=sys.stderr)
        self.page.goto(PARTNER_LIST_URL, wait_until="domcontentloaded", timeout=60000)
        self.page.wait_for_timeout(5000)

        india_filter_remove = self.page.locator("xpath=//span[text()='Country: India']/following-sibling::span[contains(@class, 'close') or contains(@class, 'remove')]")
        if india_filter_remove.count() > 0:
            india_filter_remove.first.click()
            self.page.wait_for_timeout(2000)

        experience_header = self.page.locator("xpath=//span[text()='Experience']/parent::div")
        try:
            experience_header.wait_for(state="visible", timeout=10000)
            experience_header.click()
            self.page.wait_for_timeout(1000)
        except Exception: pass

        for kw in ['7 - 9 years', 'More than 9 years']:
            try:
                cb = self.page.locator(f"xpath=//label[contains(., '{kw}')]")
                cb.wait_for(state="visible", timeout=5000)
                cb.click()
                self.page.wait_for_timeout(2000)
            except Exception: pass
            
        self.page.wait_for_timeout(3000)

    def get_all_partners(self) -> list[dict]:
        print("[*] Extracting partner list...", file=sys.stderr)
        self._scroll_to_bottom()
        partners = []
        cards = self.page.locator("li.partner-card, li:has(strong)").all()
        for card in cards:
            try:
                name_el = card.locator("strong, .partner-name, h3").first
                if name_el.count() == 0: continue
                name = name_el.inner_text().strip()
                link_el = card.locator("a[href*='partner']").first
                href = link_el.get_attribute("href") if link_el.count() > 0 else None
                if name and href:
                    abs_url = self._absolute_url(href)
                    if "find-partner-profile.html" in abs_url or "partnerid=" in abs_url:
                        partners.append({"name": name, "url": abs_url})
            except Exception: continue
        return partners

    def find_partner(self) -> str:
        # 1. Check if it's already a URL
        if self.partner_name.startswith("http"):
            return self.partner_name

        # 2. Check if it's a Hex ID
        if re.match(r"^[a-fA-F0-9]{30,}$", self.partner_name):
            return f"https://www.zoho.com/partners/find-partner-profile.html?partnerid={self.partner_name}"

        print(f"[*] Searching for partner: {self.partner_name!r}", file=sys.stderr)
        self._safe_goto(PARTNER_SEARCH_URL, timeout=45000)
        self.page.wait_for_timeout(3000)

        search_selectors = ["#search-partner", "input#search-partner", "input[placeholder*='search' i]"]
        search_input = None
        for sel in search_selectors:
            el = self.page.query_selector(sel)
            if el and el.is_visible():
                search_input = el
                break

        if search_input:
            search_input.fill(self.partner_name)
            search_input.press("Enter")
            self.page.wait_for_timeout(3000)
        
        self._scroll_to_bottom()
        partner_url = self._find_matching_card()
        if partner_url: return partner_url
        raise RuntimeError(f"Partner '{self.partner_name}' not found.")

    def _find_matching_card(self) -> str | None:
        target = self.partner_name.lower().strip()
        profile_link_patterns = ["a[href*='find-partner-profile.html']", "a[href*='partnerid=']"]
        for sel in profile_link_patterns:
            anchors = self.page.query_selector_all(sel)
            for anchor in anchors:
                try:
                    text = anchor.inner_text().strip().lower()
                    href = anchor.get_attribute("href") or ""
                    if target in text or text in target:
                        abs_url = self._absolute_url(href)
                        if "find-partner-profile.html" in abs_url: return abs_url
                except Exception: continue
        return None

    def extract_partner_data(self, profile_url: str, manual_links: dict | None = None) -> dict:
        print(f"[*] Opening profile: {profile_url}", file=sys.stderr)
        try:
            # Use domcontentloaded instead of networkidle to avoid hangs on tracking scripts
            success = self._safe_goto(profile_url, timeout=90000)
            if not success:
                 print(f"[-] Warning: Initial page load for {profile_url} failed.", file=sys.stderr)
            self.page.wait_for_timeout(4000)
            self._scroll_to_bottom()
        except Exception as e:
            print(f"[-] Warning: Error during initial page load for {profile_url}: {e}", file=sys.stderr)

        # Detect if this is a Zoho profile or an external website
        is_zoho_profile = "zoho.com" in profile_url and ("find-partner-profile.html" in profile_url or "partnerid=" in profile_url)

        if is_zoho_profile:
            from urllib.parse import parse_qs
            parsed_url = urlparse(profile_url)
            params = parse_qs(parsed_url.query)
            partner_id = params.get('partnerid', ['unknown'])[0]

            # Call modularized extractors for Zoho
            data = {
                "partner_id": partner_id,
                "name": extract_name(self),
                "overview": extract_overview(self),
                "website": extract_website(self),
                "linkedin": extract_linkedin(self),
                "customer_stories": extract_customer_stories(self),
                "blogs": [], # Prioritize external website for blogs
                "case_studies": [], # Prioritize external website for cases
                "social_media": {"instagram": None, "twitter": None, "facebook": None, "youtube": None},
                "parent_company": self.parent_company
            }

            # Optional: Peek at Zoho for blogs/cases only if website is missing
            if not data["website"]:
                data["blogs"] = extract_blogs(self)
                data["case_studies"] = extract_case_studies(self)

            # Extract content for Zoho-found stories (since they are only links in the profile view)
            if data["customer_stories"]:
                print(f"[*] Extracting content for {len(data['customer_stories'])} stories found on Zoho profile...", file=sys.stderr)
                for item in data["customer_stories"][:5]: # Limit to 5 for speed
                    if item.get("link") and (not item.get("content") or "failed" in item.get("content", "").lower()):
                        item["content"] = extract_page_content(self, item["link"])
        else:
            # Handle as external website directly
            print(f"[*] Treating {profile_url} as external website...", file=sys.stderr)
            url_hash = hashlib.md5(profile_url.encode()).hexdigest()[:12]
            
            # Try to get a cleaner name from the page title if extract_name fails
            page_title = ""
            try:
                page_title = self.page.title()
            except: pass

            extracted_name = extract_name(self)
            
            # If the extracted name is too long or generic (like 'Zoho Consultants'), use AI to get the actual brand name
            lower_name = extracted_name.lower()
            if len(extracted_name) > 35 or \
               any(word in lower_name for word in ["way to", "welcome", "home", "the easiest", "zoho consultant", "zoho partner"]):
                print(f"[*] Extracted name '{extracted_name}' looks generic. Using AI to find actual brand name...", file=sys.stderr)
                name = self.analyzer.extract_company_name_with_ai(profile_url)
            else:
                name = extracted_name

            data = {
                "partner_id": f"ext_{url_hash}",
                "name": name,
                "overview": extract_overview(self) or "No overview found on external site.",
                "website": profile_url,
                "linkedin": None,
                "customer_stories": [],
                "blogs": [],
                "case_studies": [],
                "social_media": {"instagram": None, "twitter": None, "facebook": None, "youtube": None},
                "parent_company": self.parent_company
            }

        if data["website"]:
            print(f"\n[?] Scrapped Overview and Customer Stories for {data['name']}.")
            print(f"Official Website: {data['website']}")
            
            # --- AI Link Discovery ---
            print(f"[*] AI is discovering Blog and Case Study links for {data['website']}...", file=sys.stderr)
            ai_blog_url, ai_case_url = None, None
            try:
                self._safe_goto(data["website"], timeout=60000)
                self.page.wait_for_timeout(2000)

                # --- Language Switching ---
                self._try_switch_to_english()
                
                # --- Fallback LinkedIn Extraction ---
                if not data["linkedin"]:
                    data["linkedin"] = extract_linkedin_from_external(self, data["website"])
                    if data["linkedin"]:
                        print(f"[+] Discovered LinkedIn from website: {data['linkedin']}")

                _expand_nav_fully(self.page)
                
                # Get the domain to filter internal links (clean of www. for better matching)
                domain = urlparse(data["website"]).netloc.replace("www.", "")
                
                # --- Social Media Discovery & Scraping ---
                print(f"[*] Discovering Social Media links from {data['website']}...", file=sys.stderr)
                social_links = extract_social_links(self)
                
                # AI Fallback for missing social links
                if not all(social_links.values()):
                    ai_social = self.analyzer.find_social_links_with_ai(data["name"], data["website"])
                    for platform, url in ai_social.items():
                        if platform == "linkedin":
                            if not data["linkedin"] and url:
                                data["linkedin"] = url
                                print(f"[+] AI Discovered LinkedIn: {url}")
                        elif not social_links.get(platform) and url:
                            print(f"[+] AI Discovered {platform}: {url}")
                            social_links[platform] = url
                
                # Scrape each platform
                for platform, url in social_links.items():
                    if url:
                        data["social_media"][platform] = scrape_social_platform(self, url, platform)
                
                nav_links = _collect_all_nav_links(self.page, domain)
                
                # 2. Use AI to find listing pages
                discovered = self.analyzer.find_listing_links(data["website"], nav_links)
                ai_blog_url = discovered.get("blog_url")
                ai_case_url = discovered.get("case_study_url")
                ai_story_url = discovered.get("customer_story_url")
                
                if ai_blog_url: print(f"[+] AI Found Blog Link: {ai_blog_url}")
                if ai_case_url: print(f"[+] AI Found Case Study Link: {ai_case_url}")
                if ai_story_url: print(f"[+] AI Found Customer Story Link: {ai_story_url}")

                # --- MANUAL OVERRIDE ---
                if manual_links:
                    if manual_links.get("blog_url"): 
                        print(f"[*] Using manual blog link: {manual_links['blog_url']}", file=sys.stderr)
                        ai_blog_url = manual_links["blog_url"]
                    if manual_links.get("case_study_url"):
                        print(f"[*] Using manual case study link: {manual_links['case_study_url']}", file=sys.stderr)
                        ai_case_url = manual_links["case_study_url"]
                    if manual_links.get("customer_story_url"):
                        print(f"[*] Using manual customer story link: {manual_links['customer_story_url']}", file=sys.stderr)
                        ai_story_url = manual_links["customer_story_url"]
                    
                    # Update social links if provided manually
                    for platform in ["instagram", "twitter", "facebook", "youtube"]:
                        if manual_links.get(f"{platform}_url"):
                            print(f"[*] Using manual {platform} link: {manual_links[f'{platform}_url']}", file=sys.stderr)
                            social_links[platform] = manual_links[f"{platform}_url"]

                # --- Deep Scraping from Listing Pages ---
                external_data = extract_from_manual_links(self, ai_blog_url, ai_case_url, ai_story_url)
                
                # --- MERGE & DEDUP LOGIC (Zoho Ground Truth) ---
                def merge_and_dedup(base_data, new_external):
                    seen_links = {} 
                    for cat in ["customer_stories", "blogs", "case_studies"]:
                        for item in base_data[cat]:
                            link = item.get('link', '').rstrip('/')
                            if link: seen_links[link] = cat
                    
                    for cat, items in new_external.items():
                        for item in items:
                            link = item.get('link', '').rstrip('/')
                            if not link: continue
                            if link in seen_links:
                                target_cat = seen_links[link]
                                for existing in base_data[target_cat]:
                                    if existing.get('link', '').rstrip('/') == link:
                                        if "failed" in existing.get('content', '').lower() or not existing.get('content'):
                                            existing['content'] = item.get('content')
                                        break
                            else:
                                base_data[cat].append(item)
                                seen_links[link] = cat
                
                merge_and_dedup(data, external_data)
                # Final fallback if deep links weren't enough or found
                if not (ai_blog_url or ai_case_url or ai_story_url):
                    print(f"[*] No deep listing links found. Performing general external scan...", file=sys.stderr)
                    external_data = extract_from_external_website(self, data["website"])
                    merge_and_dedup(data, external_data)

            except Exception as e:
                print(f"[*] AI Link Discovery warning: {e}", file=sys.stderr)
                # Ensure we at least try a general scan if AI fails
                try:
                    ext_data = extract_from_external_website(self, data["website"])
                    # Simple merge if merge_and_dedup isn't defined here
                    for k, v in ext_data.items(): data[k].extend(v)
                except: pass
            
            # Combine into a single list for processing, with customer stories first to ensure priority
            all_items = data["customer_stories"] + data["blogs"] + data["case_studies"]
            
            data["customer_stories"], data["blogs"], data["case_studies"] = [], [], []
            seen_links = set()
            policy_patterns = ["privacy-policy", "cookie-policy", "terms-of-use", "term-of-use", "terms-and-conditions", "cookies-policy"]
            
            for item in all_items:
                link = item["link"].rstrip("/")
                title = item.get("title", "").lower()
                dtype = item.get("detected_type")

                if link in seen_links: continue
                if any(p in link.lower() for p in policy_patterns) or \
                   (any(kw in title for kw in ["privacy", "cookie", "terms of use"]) and "policy" in title):
                    continue
                
                # Discard common non-content links and listing pages
                if any(kw in link.lower() for kw in ["/contact", "/about", "/career", "/team", "/pricing", "/login", "/signup"]):
                    continue
                
                # If it's a listing page link, we'll crawl it via external site logic, 
                # but don't treat it as a single content item.
                if any(link.lower().endswith(p) for p in ["/blog", "/blogs", "/case-studies", "/case-study", "/success-stories"]):
                    continue

                seen_links.add(link)
                
                # Priority 1: Explicitly detected type from tabs
                if dtype == "blogs":
                    data["blogs"].append(item)
                elif dtype == "customer_stories":
                    data["customer_stories"].append(item)
                elif dtype == "case_studies":
                    data["case_studies"].append(item)
                
                # Priority 2: Pattern-based fallback
                elif any(kw in link.lower() for kw in ["/blog", "/article", "/insight"]):
                    data["blogs"].append(item)
                elif "zoho.com" in link.lower() or any(kw in link.lower() for kw in ["/customer-stor", "/testimonial"]):
                    data["customer_stories"].append(item)
                elif any(kw in link.lower() for kw in ["/case-stud", "/success-stor", "/portfolio"]):
                    # Avoid WorkDrive or external docs here
                    if "workdrive" not in link.lower() and "drive.google" not in link.lower():
                        data["case_studies"].append(item)
                else:
                    # Default to case studies if it looks like a resource but not specifically a blog
                    if any(kw in link.lower() for kw in ["/resource", "/work"]) and "workdrive" not in link.lower():
                        data["case_studies"].append(item)

            # Limit and Fetch Content
            MAX_FETCH = 5
            for category in ["blogs", "case_studies", "customer_stories"]:
                print(f"[*] Fetching content for top {MAX_FETCH} items in {category}...", file=sys.stderr)
                items_to_fetch = data[category][:MAX_FETCH]
                data[category] = items_to_fetch # Keep only limited items for analysis
                
                for item in items_to_fetch:
                    link = item["link"].lower().rstrip("/")
                    # Skip fetching if content exists or if it looks like a listing page
                    if item.get("content") or any(link.endswith(p) for p in ["/blog", "/blogs", "/case-studies", "/case-study", "/success-stories", "/resources"]):
                        if not item.get("content"):
                            item["content"] = "Listing page link - skipping direct content extraction."
                        continue
                        
                    content = extract_page_content(self, item["link"])
                    if content:
                        # Use AI to format/summarize the raw content into "formatted words"
                        item["content"] = self.analyzer.summarize_content(item.get("title", ""), content)
                    else:
                        item["content"] = "Content extraction failed or page is empty."
            
            print(f"[*] Extraction complete: {len(data['customer_stories'])} stories, {len(data['blogs'])} blogs, {len(data['case_studies'])} case studies.", file=sys.stderr)
        return data

    def _merge_items(self, original: list, new: list) -> list:
        seen_links = {item["link"].rstrip("/") for item in original if "link" in item and item["link"]}
        for item in new:
            link = item.get("link", "").rstrip("/")
            if link and link not in seen_links:
                original.append(item)
                seen_links.add(link)
        return original

    def _anchor_to_item(self, anchor) -> dict | None:
        try:
            title = anchor.inner_text().strip()
            href = anchor.get_attribute("href") or ""
            if not title or not href or "javascript" in href.lower(): return None
            return {"title": title, "link": self._absolute_url(href)}
        except Exception: return None

    def _extract_items_from_section(self, section_keywords: list[str]) -> list[dict]:
        results = []
        heading_selectors = ["h2", "h3", "h4", ".section-title"]
        for h_sel in heading_selectors:
            for heading in self.page.query_selector_all(h_sel):
                try:
                    heading_text = heading.inner_text().strip().lower()
                    if not any(kw in heading_text for kw in section_keywords): continue
                    parent = heading.evaluate_handle("el => el.parentElement")
                    if parent:
                        anchors = parent.query_selector_all("a")
                        for anchor in anchors:
                            item = self._anchor_to_item(anchor)
                            if item: results.append(item)
                except Exception: continue
        return results
    def run(self) -> dict | list[dict]:
        with sync_playwright() as playwright:
            self._launch(playwright)
            try:
                if self.partner_name:
                    profile_url = self.find_partner()
                    return self.extract_partner_data(profile_url, getattr(self, "manual_links", None))
                else:
                    self.apply_filters()
                    return self.get_all_partners()
            finally: self._close()
